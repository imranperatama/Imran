# GameForge AI — IMRAN MAX v0.3

Upgrade dari prototype:
- IMRAN Planner lokal (deterministic local planner, no API)
- Scene runtime
- procedural platform generation
- procedural humanoid blockout
- humanoid rig data
- animation clip data
- BUILD → TEST → FIX → LEARN loop
- persistent project + experience memory
- export project JSON

Contoh:
"Bikin game parkour 3D, karakter manusia, 20 platform, checkpoint dan finish."

Catatan jujur:
v0.3 sudah menjalankan pipeline internal secara nyata, tetapi belum merupakan neural model besar atau Blender-level 3D engine. Langkah berikutnya adalah memasukkan real 3D rendering/mesh topology, local ML planner/runtime, skinning, physics, dan evaluasi visual.
