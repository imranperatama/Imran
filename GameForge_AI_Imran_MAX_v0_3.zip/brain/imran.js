export class IMRANPlanner{
 plan(prompt){
  const p=prompt.toLowerCase(), human=/human|manusia|player|karakter/.test(p);
  const parkour=/parkour|platform/.test(p);
  const n=(p.match(/(\d+)\s*platform/)||[])[1]||6;
  const objects=[];
  if(parkour) for(let i=0;i<Math.min(+n,50);i++) objects.push({name:"Platform "+(i+1),type:"box",x:30+i*75,y:45+(i%5)*55,w:65,h:16});
  else objects.push({name:"Start",type:"box",x:80,y:60,w:100,h:20});
  return {name:human?"IMRAN Generated Game":"IMRAN Project",human,objects,
   logic:["START","INPUT","MOVE","JUMP","COLLISION","CHECKPOINT","FINISH"]};
 }
}