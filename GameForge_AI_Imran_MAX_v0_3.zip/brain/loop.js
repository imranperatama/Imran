export class AdaptiveLoop{
 constructor(state){this.state=state;this.lastFix=null}
 test(project){
  const errors=[];
  if(!project.objects.length) errors.push("Scene kosong");
  for(let i=1;i<project.objects.length;i++){
   if(Math.abs((project.objects[i].x||0)-(project.objects[i-1].x||0))>250) errors.push("Objek terlalu jauh: "+project.objects[i].name)
  }
  return {ok:errors.length===0,errors};
 }
 fix(project){
  const t=this.test(project); if(t.ok){this.lastFix="Tidak ada koreksi";return {fixed:false,reason:"No error"}}
  for(const o of project.objects){if((o.x||0)>430)o.x=430}
  this.lastFix="Clamp posisi objek keluar scene ke batas runtime";
  return {fixed:true,action:this.lastFix};
 }
 learn(error,fix,result){
  const e={error,fix,result,time:new Date().toISOString()};
  this.state.experience.push(e);return e;
 }
}