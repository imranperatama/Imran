export class SceneEngine{
 constructor(project){this.project=project}
 clear(){this.project.objects=[]}
 add(o){this.project.objects.push({...o,id:crypto.randomUUID(),generated:true})}
 render(el){
  el.innerHTML="";
  for(const o of this.project.objects){
   const e=document.createElement("div");e.className="obj";e.textContent=o.name||o.type;
   e.style.left=(o.x??80)+"px";e.style.top=(400-(o.y??80))+"px";
   e.style.width=(o.w??45)+"px";e.style.height=(o.h??45)+"px";
   e.style.borderRadius=o.type==="sphere"?"50%":"7px";
   el.appendChild(e);
  }
 }
}