export class HumanSystem{
 create(scene){
  const parts=[
   ["Head","sphere",210,300,48,48],["Torso","box",195,205,78,95],
   ["Arm.L","box",165,220,20,80],["Arm.R","box",283,220,20,80],
   ["Leg.L","box",205,105,25,105],["Leg.R","box",238,105,25,105]
  ];
  parts.forEach(p=>scene.add({name:p[0],type:p[1],x:p[2],y:p[3],w:p[4],h:p[5]}))
 }
 rig(){return {type:"humanoid",bones:[
  "root","pelvis","spine","head","upperArm.L","lowerArm.L","hand.L",
  "upperArm.R","lowerArm.R","hand.R","upperLeg.L","lowerLeg.L","foot.L",
  "upperLeg.R","lowerLeg.R","foot.R"]}}
 animations(){return {idle:{duration:1.2},walk:{duration:.8},run:{duration:.55},jump:{duration:.9}}}
}