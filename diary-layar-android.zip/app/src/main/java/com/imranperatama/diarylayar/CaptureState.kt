package com.imranperatama.diarylayar

object CaptureState {
    var isCapturing: Boolean = false
    var frameCount: Int = 0

    interface Listener {
        fun onCaptureStateChanged(capturing: Boolean, frameCount: Int)
    }

    private val listeners = mutableListOf<Listener>()

    fun addListener(listener: Listener) {
        listeners.add(listener)
        listener.onCaptureStateChanged(isCapturing, frameCount)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    fun update(capturing: Boolean, count: Int) {
        isCapturing = capturing
        frameCount = count
        listeners.toList().forEach { it.onCaptureStateChanged(capturing, count) }
    }
}
