package com.imranperatama.diarylayar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.imranperatama.diarylayar.START"
        const val ACTION_STOP = "com.imranperatama.diarylayar.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_INTERVAL_SEC = "intervalSec"
        private const val CHANNEL_ID = "diary_layar_capture"
        private const val NOTIF_ID = 1001
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var handler: Handler? = null
    private var intervalMs: Long = 1000
    private var frameCount = 0

    private var screenWidth = 720
    private var screenHeight = 1280
    private var screenDensity = 320

    private val captureRunnable = object : Runnable {
        override fun run() {
            captureFrame()
            handler?.postDelayed(this, intervalMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                val intervalSec = intent.getIntExtra(EXTRA_INTERVAL_SEC, 1)
                intervalMs = intervalSec.coerceAtLeast(1) * 1000L

                startForegroundWithNotification(0)

                if (resultCode != -1 && data != null) {
                    startCapture(resultCode, data)
                }
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification(count: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Diary Layar - Rekam Layar",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = buildNotification(count)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun buildNotification(count: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Diary Layar sedang merekam")
            .setContentText("$count foto direkam sejauh ini")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(count: Int) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(count))
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val projection = projectionManager.getMediaProjection(resultCode, data) ?: return
        mediaProjection = projection

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
            }
        }, null)

        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = projection.createVirtualDisplay(
            "DiaryLayarCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null, null
        )

        handlerThread = HandlerThread("DiaryLayarCaptureThread").also { it.start() }
        handler = Handler(handlerThread!!.looper)
        frameCount = 0
        CaptureState.update(true, 0)

        handler?.postDelayed(captureRunnable, 400)
    }

    private fun captureFrame() {
        val reader = imageReader ?: return
        val image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return

        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)

            saveBitmap(cropped)

            bitmap.recycle()
            cropped.recycle()

            frameCount++
            CaptureState.update(true, frameCount)
            updateNotification(frameCount)
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            image.close()
        }
    }

    private fun saveBitmap(bitmap: Bitmap) {
        try {
            val dir = File(getExternalFilesDir(null), "DiaryLayar")
            if (!dir.exists()) dir.mkdirs()

            val file = File(dir, "ss_${System.currentTimeMillis()}_${frameCount + 1}.jpg")

            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopCapture() {
        handler?.removeCallbacks(captureRunnable)
        handlerThread?.quitSafely()
        handlerThread = null
        handler = null

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.close()
        imageReader = null

        mediaProjection?.stop()
        mediaProjection = null

        CaptureState.update(false, frameCount)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
