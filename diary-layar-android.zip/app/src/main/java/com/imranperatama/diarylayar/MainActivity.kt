package com.imranperatama.diarylayar

import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var intervalInput: EditText
    private lateinit var captureOrb: ImageButton
    private lateinit var captureTitle: TextView
    private lateinit var captureDesc: TextView
    private lateinit var statusText: TextView

    private lateinit var projectionManager: MediaProjectionManager
    private var isCapturing = false

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val intervalSec = intervalInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1

            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_INTERVAL_SEC, intervalSec)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            setCapturingUi(true)
        } else {
            statusText.text = "Izin rekam layar dibatalkan."
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { requestScreenCapture() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        intervalInput = findViewById(R.id.intervalInput)
        captureOrb = findViewById(R.id.captureOrb)
        captureTitle = findViewById(R.id.captureTitle)
        captureDesc = findViewById(R.id.captureDesc)
        statusText = findViewById(R.id.statusText)

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        captureOrb.setOnClickListener {
            if (isCapturing) stopCapture() else onStartClicked()
        }

        findViewById<android.widget.TextView>(R.id.preset1).setOnClickListener { intervalInput.setText("1") }
        findViewById<android.widget.TextView>(R.id.preset5).setOnClickListener { intervalInput.setText("5") }
        findViewById<android.widget.TextView>(R.id.preset15).setOnClickListener { intervalInput.setText("15") }

        findViewById<android.widget.Button>(R.id.galleryButton).setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        updateFrameCount()
    }

    override fun onResume() {
        super.onResume()
        updateFrameCount()
    }

    private fun updateFrameCount() {
        val dir = File(getExternalFilesDir(null), "DiaryLayar")
        val count = dir.listFiles()?.count { it.extension == "jpg" } ?: 0
        if (!isCapturing) {
            statusText.text = if (count == 0) "Siap. Belum ada foto." else "$count foto tersimpan."
        }
    }

    private fun setCapturingUi(capturing: Boolean) {
        isCapturing = capturing
        if (capturing) {
            captureOrb.setBackgroundResource(R.drawable.bg_capture_circle_live)
            captureOrb.setImageResource(R.drawable.ic_stop)
            captureTitle.text = "STOP REKAM"
            captureDesc.text = "Lagi jepret otomatis..."
            statusText.text = "Merekam... foto otomatis kesimpen di Diary."
        } else {
            captureOrb.setBackgroundResource(R.drawable.bg_capture_circle)
            captureOrb.setImageResource(R.drawable.ic_camera)
            captureTitle.text = "MULAI REKAM LAYAR"
            captureDesc.text = "Tap buat minta izin & mulai jepret otomatis"
            updateFrameCount()
        }
    }

    private fun stopCapture() {
        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(stopIntent)
        setCapturingUi(false)
    }

    private fun onStartClicked() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) {
                notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
