package com.imranperatama.diarylayar

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class GalleryActivity : AppCompatActivity() {

    private lateinit var grid: RecyclerView
    private lateinit var countText: TextView
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        grid = findViewById(R.id.photoGrid)
        countText = findViewById(R.id.countText)
        emptyText = findViewById(R.id.emptyText)
        grid.layoutManager = GridLayoutManager(this, 3)

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }

        findViewById<Button>(R.id.shareAllButton).setOnClickListener { shareAll() }
        findViewById<Button>(R.id.clearAllButton).setOnClickListener { clearAll() }

        loadPhotos()
    }

    private fun photoDir() = File(getExternalFilesDir(null), "DiaryLayar")

    private fun loadPhotos() {
        val files = photoDir().listFiles()
            ?.filter { it.extension == "jpg" }
            ?.sortedBy { it.name }
            ?: emptyList()

        countText.text = "${files.size} foto"
        emptyText.visibility = if (files.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        grid.visibility = if (files.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE

        grid.adapter = PhotoAdapter(
            files,
            onClick = { position ->
                val intent = Intent(this, FlipbookActivity::class.java)
                intent.putExtra(
                    FlipbookActivity.EXTRA_PATHS,
                    files.map { it.absolutePath }.toTypedArray()
                )
                intent.putExtra(FlipbookActivity.EXTRA_START_INDEX, position)
                startActivity(intent)
            },
            onDelete = { file ->
                file.delete()
                loadPhotos()
            }
        )
    }

    private fun shareAll() {
        val files = photoDir().listFiles()?.filter { it.extension == "jpg" } ?: emptyList()
        if (files.isEmpty()) return

        val uris = ArrayList<Uri>()
        for (file in files) {
            uris.add(
                FileProvider.getUriForFile(
                    this, "com.imranperatama.diarylayar.fileprovider", file
                )
            )
        }

        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/jpeg"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Bagikan foto diary"))
    }

    private fun clearAll() {
        photoDir().listFiles()?.forEach { it.delete() }
        loadPhotos()
    }

    override fun onResume() {
        super.onResume()
        loadPhotos()
    }
}
