package com.imranperatama.diarylayar

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class PhotoAdapter(
    private val files: List<File>,
    private val onClick: (Int) -> Unit,
    private val onDelete: (File) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoHolder>() {

    class PhotoHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.photoThumb)
        val deleteBtn: ImageButton = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_photo, parent, false)
        return PhotoHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoHolder, position: Int) {
        val file = files[position]
        val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, opts)
        holder.image.setImageBitmap(bitmap)
        holder.image.setOnClickListener { onClick(position) }
        holder.deleteBtn.setOnClickListener { onDelete(file) }
    }

    override fun getItemCount(): Int = files.size
}
