package com.imranperatama.diarylayar

import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FlipbookActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATHS = "paths"
        const val EXTRA_START_INDEX = "startIndex"
    }

    private lateinit var paths: Array<String>
    private var index = 0
    private lateinit var flipImage: ImageView
    private lateinit var flipHint: TextView
    private lateinit var playPauseBtn: ImageButton

    private var dragStartX = 0f
    private var dragStartIndex = 0

    private var playing = false
    private val handler = Handler(Looper.getMainLooper())
    private var speedMs = 900L

    private val playRunnable = object : Runnable {
        override fun run() {
            if (!playing || paths.isEmpty()) return
            index = (index + 1) % paths.size
            renderFrame()
            handler.postDelayed(this, speedMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flipbook)

        flipImage = findViewById(R.id.flipImage)
        flipHint = findViewById(R.id.flipHint)
        playPauseBtn = findViewById(R.id.flipPlayPause)

        paths = intent.getStringArrayExtra(EXTRA_PATHS) ?: emptyArray()
        index = intent.getIntExtra(EXTRA_START_INDEX, 0).coerceIn(0, (paths.size - 1).coerceAtLeast(0))

        renderFrame()

        findViewById<ImageButton>(R.id.flipBackButton).setOnClickListener { finish() }

        playPauseBtn.setOnClickListener {
            playing = !playing
            playPauseBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            if (playing) handler.postDelayed(playRunnable, speedMs)
        }

        findViewById<SeekBar>(R.id.flipSpeed).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                speedMs = (2000 - progress).coerceAtLeast(100).toLong()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        flipImage.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    playing = false
                    playPauseBtn.setImageResource(R.drawable.ic_play)
                    dragStartX = event.x
                    dragStartIndex = index
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - dragStartX
                    val step = (dx / 40).toInt()
                    val newIndex = (dragStartIndex - step).coerceIn(0, (paths.size - 1).coerceAtLeast(0))
                    if (newIndex != index) {
                        index = newIndex
                        renderFrame()
                    }
                }
            }
            true
        }
    }

    private fun renderFrame() {
        if (paths.isEmpty()) {
            flipHint.text = "Belum ada foto."
            return
        }
        val bitmap = BitmapFactory.decodeFile(paths[index])
        flipImage.setImageBitmap(bitmap)
        flipHint.text = "Foto ${index + 1}/${paths.size} — geser atau tekan play"
    }

    override fun onDestroy() {
        handler.removeCallbacks(playRunnable)
        super.onDestroy()
    }
}
