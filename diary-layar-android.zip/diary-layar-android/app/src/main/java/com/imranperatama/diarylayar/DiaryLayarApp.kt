package com.imranperatama.diarylayar

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Nyimpen stack trace tiap kali app crash, biar kebaca di dialog
 * pas app dibuka lagi (bukan cuma "telah berhenti").
 */
class DiaryLayarApp : Application() {

    override fun onCreate() {
        super.onCreate()

        val previous = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val dir = getExternalFilesDir(null) ?: filesDir
                File(dir, "crash_log.txt").writeText(
                    "Waktu: ${java.util.Date()}\nThread: ${thread.name}\n\n$sw"
                )
            } catch (e: Throwable) {
                // gagal nulis log jangan sampai bikin crash dobel
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
