package com.imranperatama.diarylayar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Service rekam layar.
 *
 * Cara kerja (sengaja dibuat tahan banting):
 *  - ImageReader pakai listener. Tiap ada frame baru, frame TERBARU disimpan di memori ("held").
 *    Layar yang diem (nggak ada perubahan) nggak ngirim frame baru, makanya dulu polling
 *    acquireLatestImage() sering dapet null terus -> 0 foto. Sekarang frame terakhir tetap dipegang.
 *  - Tiap interval, frame yang dipegang itu di-convert jadi JPEG dan disimpen.
 *  - Semua error ditulis ke capture_log.txt + ditampilin di notifikasi, nggak ada yang diem-diem.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.imranperatama.diarylayar.START"
        const val ACTION_STOP = "com.imranperatama.diarylayar.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_INTERVAL_MS = "intervalMs"

        private const val CHANNEL_ID = "diary_layar_capture"
        private const val CHANNEL_ERR_ID = "diary_layar_error"
        private const val NOTIF_ID = 1001
        private const val NOTIF_ERR_ID = 1003
        private const val MAX_DIM = 1280
        private const val MIN_FREE_BYTES = 40L * 1024 * 1024

        fun baseDir(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir

        fun photoDir(ctx: Context): File = File(baseDir(ctx), "DiaryLayar")

        fun logFile(ctx: Context): File = File(baseDir(ctx), "capture_log.txt")

        fun logLine(ctx: Context, msg: String) {
            try {
                val f = logFile(ctx)
                if (f.exists() && f.length() > 200_000) f.delete()
                val t = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
                f.appendText("$t  $msg\n")
            } catch (e: Throwable) {
                // log gagal ditulis, abaikan
            }
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var handler: Handler? = null

    private var intervalMs = 1000L
    private var frameCount = 0
    private var running = false
    private var stopping = false
    private var held: Image? = null
    private var framesSeen = 0
    private var noFrameTicks = 0
    private var failedSaves = 0

    private var screenWidth = 720
    private var screenHeight = 1280
    private var screenDensity = 320

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            logLine(this@ScreenCaptureService, "Proyeksi dihentikan sistem/user")
            stopCapture()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            doTick()
            handler?.postDelayed(this, intervalMs)
        }
    }

    private val watchdogRunnable = Runnable {
        if (running && framesSeen == 0) {
            val msg = "4 detik belum ada frame dari layar. Coba stop lalu mulai lagi."
            logLine(this, msg)
            CaptureState.lastError = msg
            updateNotification(msg)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                logLine(this, "STOP diminta")
                stopCapture()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // WAJIB langsung startForeground, kalau telat Android matiin app.
                try {
                    startForegroundWithNotification()
                } catch (t: Throwable) {
                    logLine(this, "startForeground gagal: ${t.javaClass.simpleName}: ${t.message}")
                    fail("startForeground gagal: ${t.message}")
                    return START_NOT_STICKY
                }

                if (running) {
                    logLine(this, "START diabaikan, udah merekam")
                    return START_NOT_STICKY
                }

                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                intervalMs = intent.getLongExtra(EXTRA_INTERVAL_MS, 1000L).coerceAtLeast(200L)

                if (data == null) {
                    fail("Data izin rekam layar kosong")
                    return START_NOT_STICKY
                }

                try {
                    startCapture(resultCode, data)
                } catch (t: Throwable) {
                    logLine(this, "startCapture gagal: ${trace(t)}")
                    fail("${t.javaClass.simpleName}: ${t.message}")
                }
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun trace(t: Throwable): String = android.util.Log.getStackTraceString(t)

    // ---------------------------------------------------------------- notifikasi

    private fun ensureChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Diary Layar - Rekam Layar", NotificationManager.IMPORTANCE_LOW)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ERR_ID, "Diary Layar - Error", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun startForegroundWithNotification() {
        ensureChannels()
        val notification = buildNotification("Menyiapkan rekam layar...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Diary Layar sedang merekam")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        } catch (t: Throwable) {
            // abaikan
        }
    }

    private fun showErrorNotification(msg: String) {
        try {
            ensureChannels()
            val openApp = PendingIntent.getActivity(
                this, 2, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, CHANNEL_ERR_ID)
                .setContentTitle("Diary Layar GAGAL merekam")
                .setContentText(msg)
                .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentIntent(openApp)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTIF_ERR_ID, n)
        } catch (t: Throwable) {
            // abaikan
        }
    }

    private fun fail(msg: String) {
        logLine(this, "GAGAL: $msg")
        CaptureState.lastError = msg
        stopCapture()
        showErrorNotification(msg)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- capture

    private fun computeScreenSize() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            screenWidth = b.width()
            screenHeight = b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            screenWidth = m.widthPixels
            screenHeight = m.heightPixels
        }
        screenDensity = resources.displayMetrics.densityDpi
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        stopping = false
        framesSeen = 0
        noFrameTicks = 0
        failedSaves = 0
        frameCount = 0
        CaptureState.lastError = null

        logLine(this, "START interval=${intervalMs}ms sdk=${Build.VERSION.SDK_INT} model=${Build.MODEL}")

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = pm.getMediaProjection(resultCode, data)
        if (projection == null) {
            fail("getMediaProjection null (izin rekam layar ditolak/kadaluarsa)")
            return
        }
        mediaProjection = projection

        // Android 14 WAJIB: register callback sebelum createVirtualDisplay
        projection.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))

        computeScreenSize()
        logLine(this, "Ukuran layar ${screenWidth}x$screenHeight dpi=$screenDensity")

        val thread = HandlerThread("DiaryLayarCaptureThread").also { it.start() }
        handlerThread = thread
        val h = Handler(thread.looper)
        handler = h

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 4)
        imageReader = reader
        reader.setOnImageAvailableListener({ r -> onImageAvailable(r) }, h)

        val vd = projection.createVirtualDisplay(
            "DiaryLayarCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null, null
        )
        if (vd == null) {
            fail("createVirtualDisplay null")
            return
        }
        virtualDisplay = vd

        running = true
        CaptureState.update(true, 0)
        updateNotification("Merekam tiap ${formatInterval(intervalMs)}... 0 foto")

        h.postDelayed(tickRunnable, minOf(intervalMs, 500L))
        h.postDelayed(watchdogRunnable, 4000)
        logLine(this, "Virtual display jalan")
    }

    private fun formatInterval(ms: Long): String =
        if (ms % 1000L == 0L) "${ms / 1000} dtk" else String.format(Locale.US, "%.1f dtk", ms / 1000.0)

    /** Jalan di thread capture. Simpen frame terbaru, buang yang lama. */
    private fun onImageAvailable(reader: ImageReader) {
        try {
            val img = reader.acquireLatestImage() ?: return
            framesSeen++
            held?.close()
            held = img
        } catch (t: Throwable) {
            logLine(this, "onImageAvailable error: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** Jalan di thread capture tiap interval. */
    private fun doTick() {
        val img = held
        if (img == null) {
            noFrameTicks++
            if (noFrameTicks == 1 || noFrameTicks % 10 == 0) {
                logLine(this, "Tick: belum ada frame ($noFrameTicks kali)")
            }
            return
        }
        try {
            val free = photoDir(this).apply { mkdirs() }.usableSpace
            if (free < MIN_FREE_BYTES) {
                fail("Penyimpanan hampir penuh (sisa ${free / 1024 / 1024} MB)")
                return
            }
            saveImage(img)
            failedSaves = 0
            frameCount++
            CaptureState.update(true, frameCount)
            updateNotification("$frameCount foto kesimpen (tiap ${formatInterval(intervalMs)})")
            if (frameCount == 1) logLine(this, "Foto pertama kesimpen")
        } catch (t: Throwable) {
            failedSaves++
            logLine(this, "Simpan foto gagal ($failedSaves): ${trace(t)}")
            if (failedSaves >= 5) {
                fail("Gagal nyimpen foto 5x berturut-turut: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun saveImage(image: Image) {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val w = image.width
        val h = image.height
        val paddedWidth = rowStride / pixelStride

        val full = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(buffer)

        val cropped = if (paddedWidth != w) Bitmap.createBitmap(full, 0, 0, w, h) else full

        val maxSide = maxOf(w, h)
        val finalBmp = if (maxSide > MAX_DIM) {
            val scale = MAX_DIM.toFloat() / maxSide
            Bitmap.createScaledBitmap(cropped, (w * scale).toInt(), (h * scale).toInt(), true)
        } else cropped

        try {
            val file = File(photoDir(this), "ss_${System.currentTimeMillis()}_${frameCount + 1}.jpg")
            FileOutputStream(file).use { out ->
                if (!finalBmp.compress(Bitmap.CompressFormat.JPEG, 80, out)) {
                    throw IllegalStateException("Bitmap.compress return false")
                }
            }
            if (file.length() == 0L) throw IllegalStateException("File JPEG kosong")
        } finally {
            if (finalBmp !== cropped) finalBmp.recycle()
            if (cropped !== full) cropped.recycle()
            full.recycle()
        }
    }

    private fun stopCapture() {
        if (stopping) return
        stopping = true
        running = false
        try { handler?.removeCallbacksAndMessages(null) } catch (t: Throwable) { }
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (t: Throwable) { }
        try { held?.close() } catch (t: Throwable) { }
        held = null
        try { virtualDisplay?.release() } catch (t: Throwable) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (t: Throwable) { }
        imageReader = null
        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (t: Throwable) { }
        mediaProjection = null
        try { handlerThread?.quitSafely() } catch (t: Throwable) { }
        handlerThread = null
        handler = null
        logLine(this, "Berhenti. Total foto: $frameCount")
        CaptureState.update(false, frameCount)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
