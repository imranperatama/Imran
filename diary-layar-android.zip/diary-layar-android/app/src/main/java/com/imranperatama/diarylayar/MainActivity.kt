package com.imranperatama.diarylayar

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), CaptureState.Listener {

    private lateinit var intervalInput: EditText
    private lateinit var captureOrb: ImageButton
    private lateinit var captureTitle: TextView
    private lateinit var captureDesc: TextView
    private lateinit var statusText: TextView
    private lateinit var bubbleButton: Button

    private lateinit var projectionManager: MediaProjectionManager

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intervalMs = saveInterval()
            CaptureState.lastError = null
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
                putExtra(ScreenCaptureService.EXTRA_INTERVAL_MS, intervalMs)
            }
            try {
                ContextCompat.startForegroundService(this, serviceIntent)
                statusText.text = "Menyiapkan rekam layar..."
            } catch (t: Throwable) {
                CaptureState.lastError = "Gagal start service: ${t.javaClass.simpleName}: ${t.message}"
                ScreenCaptureService.logLine(this, CaptureState.lastError ?: "")
                refreshStatus()
            }
        } else {
            CaptureState.lastError = "Izin rekam layar dibatalkan."
            refreshStatus()
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* notifikasi tetap boleh jalan walau ditolak, cuma nggak keliatan */ }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startBubble()
        } else {
            Toast.makeText(this, "Izin 'tampil di atas app lain' belum diaktifin", Toast.LENGTH_LONG).show()
        }
        refreshBubbleButton()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        intervalInput = findViewById(R.id.intervalInput)
        captureOrb = findViewById(R.id.captureOrb)
        captureTitle = findViewById(R.id.captureTitle)
        captureDesc = findViewById(R.id.captureDesc)
        statusText = findViewById(R.id.statusText)
        bubbleButton = findViewById(R.id.bubbleButton)

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        captureOrb.setOnClickListener {
            if (CaptureState.isCapturing) stopCapture() else requestScreenCapture()
        }

        findViewById<TextView>(R.id.presetFast).setOnClickListener { intervalInput.setText("0.5"); saveInterval() }
        findViewById<TextView>(R.id.presetOne).setOnClickListener { intervalInput.setText("1"); saveInterval() }
        findViewById<TextView>(R.id.presetFive).setOnClickListener { intervalInput.setText("5"); saveInterval() }

        findViewById<Button>(R.id.galleryButton).setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        bubbleButton.setOnClickListener { onBubbleButtonClicked() }
        statusText.setOnClickListener { showLogDialog() }

        val ms = getSharedPreferences("diary_layar", MODE_PRIVATE).getLong("interval_ms", 1000L)
        intervalInput.setText(formatSeconds(ms))

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        showCrashLogIfAny()
    }

    private fun formatSeconds(ms: Long): String =
        if (ms % 1000L == 0L) (ms / 1000).toString() else String.format(Locale.US, "%.1f", ms / 1000.0)

    /** Simpen interval dalam milidetik. Boleh desimal, misal 0.5 detik. Minimal 0.2 detik. */
    private fun saveInterval(): Long {
        val sec = intervalInput.text.toString().replace(',', '.').toDoubleOrNull() ?: 1.0
        val ms = (sec * 1000).toLong().coerceIn(200L, 3_600_000L)
        getSharedPreferences("diary_layar", MODE_PRIVATE).edit().putLong("interval_ms", ms).apply()
        return ms
    }

    // ------------------------------------------------------------ log & crash

    private fun showCrashLogIfAny() {
        val f = File(ScreenCaptureService.baseDir(this), "crash_log.txt")
        if (!f.exists() || f.length() == 0L) return
        val text = try { f.readText().takeLast(3500) } catch (t: Throwable) { return }
        AlertDialog.Builder(this)
            .setTitle("App sempat crash")
            .setMessage(text)
            .setPositiveButton("Salin") { _, _ ->
                copyToClipboard(text)
                f.delete()
            }
            .setNegativeButton("Tutup") { _, _ -> f.delete() }
            .show()
    }

    private fun showLogDialog() {
        val f = ScreenCaptureService.logFile(this)
        val text = if (f.exists() && f.length() > 0) f.readText().takeLast(3500) else "(log masih kosong)"
        val err = CaptureState.lastError
        val full = (if (err != null) "ERROR TERAKHIR: $err\n\n" else "") + text
        AlertDialog.Builder(this)
            .setTitle("Log rekam layar")
            .setMessage(full)
            .setPositiveButton("Salin") { _, _ -> copyToClipboard(full) }
            .setNeutralButton("Hapus log") { _, _ ->
                f.delete()
                CaptureState.lastError = null
                refreshStatus()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Diary Layar log", text))
        Toast.makeText(this, "Disalin. Tempel ke chat.", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ ikon mengambang

    private fun onBubbleButtonClicked() {
        if (FloatingBubbleService.running) {
            stopService(Intent(this, FloatingBubbleService::class.java))
            bubbleButton.text = "Aktifkan ikon mengambang"
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Aktifin dulu 'Tampil di atas app lain' buat Diary Layar",
                Toast.LENGTH_LONG
            ).show()
            overlayPermissionLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            startBubble()
            bubbleButton.postDelayed({ refreshBubbleButton(); refreshStatus() }, 600)
        }
    }

    private fun startBubble() {
        CaptureState.lastError = null
        try {
            ContextCompat.startForegroundService(this, Intent(this, FloatingBubbleService::class.java))
        } catch (t: Throwable) {
            CaptureState.lastError = "Ikon mengambang gagal: ${t.javaClass.simpleName}: ${t.message}"
            ScreenCaptureService.logLine(this, CaptureState.lastError ?: "")
            refreshStatus()
        }
    }

    private fun refreshBubbleButton() {
        bubbleButton.text =
            if (FloatingBubbleService.running) "Matikan ikon mengambang" else "Aktifkan ikon mengambang"
    }

    // ------------------------------------------------------------ lifecycle & status

    override fun onStart() {
        super.onStart()
        CaptureState.addListener(this)
    }

    override fun onStop() {
        CaptureState.removeListener(this)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshBubbleButton()
        refreshStatus()
    }

    override fun onCaptureStateChanged(capturing: Boolean, frameCount: Int) {
        refreshStatus()
    }

    private fun refreshStatus() {
        val capturing = CaptureState.isCapturing
        if (capturing) {
            captureOrb.setBackgroundResource(R.drawable.bg_capture_circle_live)
            captureOrb.setImageResource(R.drawable.ic_stop)
            captureTitle.text = "STOP REKAM"
            captureDesc.text = "Lagi jepret otomatis..."
            statusText.text = "Merekam... ${CaptureState.frameCount} foto kesimpen sejauh ini."
        } else {
            captureOrb.setBackgroundResource(R.drawable.bg_capture_circle)
            captureOrb.setImageResource(R.drawable.ic_camera)
            captureTitle.text = "MULAI REKAM LAYAR"
            captureDesc.text = "Tap buat minta izin & mulai jepret otomatis"
            val count = ScreenCaptureService.photoDir(this).listFiles()?.count { it.extension == "jpg" } ?: 0
            val base = if (count == 0) "Siap. Belum ada foto." else "$count foto tersimpan."
            val err = CaptureState.lastError
            statusText.text = if (err != null) "GAGAL: $err\n(tap tulisan ini buat lihat log)" else "$base (tap buat lihat log)"
        }
    }

    private fun stopCapture() {
        startService(
            Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_STOP
            }
        )
    }

    private fun requestScreenCapture() {
        try {
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
        } catch (t: Throwable) {
            CaptureState.lastError = "Gagal buka dialog izin: ${t.javaClass.simpleName}: ${t.message}"
            refreshStatus()
        }
    }
}
