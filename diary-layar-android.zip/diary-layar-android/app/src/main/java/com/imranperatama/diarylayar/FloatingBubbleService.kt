package com.imranperatama.diarylayar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat

/**
 * Ikon mengambang di atas app lain (TikTok dll).
 * Tap = mulai/stop rekam. Geser = pindahin posisi.
 * Cadangan: notifikasinya juga punya tombol Mulai & Stop, kalau ikon nggak bisa dipencet.
 */
class FloatingBubbleService : Service(), CaptureState.Listener {

    companion object {
        private const val CHANNEL_ID = "diary_layar_bubble"
        private const val NOTIF_ID = 2002

        @Volatile
        var running = false
    }

    private var windowManager: WindowManager? = null
    private var bubbleView: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var listening = false

    private var initialX = 0
    private var initialY = 0
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var moved = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            startForegroundWithNotification()
        } catch (t: Throwable) {
            ScreenCaptureService.logLine(this, "Bubble: startForeground gagal: ${android.util.Log.getStackTraceString(t)}")
            CaptureState.lastError = "Ikon mengambang gagal: ${t.javaClass.simpleName}: ${t.message}"
            stopSelf()
            return
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            ScreenCaptureService.logLine(this, "Bubble: izin overlay belum aktif")
            CaptureState.lastError = "Izin 'tampil di atas app lain' belum aktif"
            stopSelf()
            return
        }

        try {
            addBubble()
            running = true
            ScreenCaptureService.logLine(this, "Bubble: tampil")
        } catch (t: Throwable) {
            ScreenCaptureService.logLine(this, "Bubble: addView gagal: ${android.util.Log.getStackTraceString(t)}")
            CaptureState.lastError = "Ikon mengambang gagal tampil: ${t.javaClass.simpleName}: ${t.message}"
            stopSelf()
        }
    }

    private fun addBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(160)
        params = lp

        val image = ImageView(this)
        image.setBackgroundResource(R.drawable.bg_capture_circle)
        image.setImageResource(R.drawable.ic_camera)
        val pad = dp(12)
        image.setPadding(pad, pad, pad, pad)
        bubbleView = image

        image.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = lp.x
                    initialY = lp.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        lp.x = initialX + dx
                        lp.y = initialY + dy
                        try { wm.updateViewLayout(image, lp) } catch (t: Throwable) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleTapped()
                    true
                }
                else -> false
            }
        }

        wm.addView(image, lp)
        CaptureState.addListener(this)
        listening = true
    }

    private fun onBubbleTapped() {
        try {
            if (CaptureState.isCapturing) {
                startService(
                    Intent(this, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_STOP
                    }
                )
            } else {
                startActivity(
                    Intent(this, TrampolineActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }
        } catch (t: Throwable) {
            ScreenCaptureService.logLine(this, "Bubble: tap gagal: ${android.util.Log.getStackTraceString(t)}")
            CaptureState.lastError = "Tap ikon gagal: ${t.javaClass.simpleName}: ${t.message}. Pakai tombol di notifikasi."
        }
    }

    override fun onCaptureStateChanged(capturing: Boolean, frameCount: Int) {
        bubbleView?.let {
            it.setBackgroundResource(
                if (capturing) R.drawable.bg_capture_circle_live else R.drawable.bg_capture_circle
            )
            it.setImageResource(if (capturing) R.drawable.ic_stop else R.drawable.ic_camera)
        }
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Diary Layar - Ikon mengambang",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val startPi = PendingIntent.getActivity(
            this, 10,
            Intent(this, TrampolineActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags
        )
        val stopPi = PendingIntent.getService(
            this, 11,
            Intent(this, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP },
            flags
        )
        val openPi = PendingIntent.getActivity(this, 12, Intent(this, MainActivity::class.java), flags)

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ikon Diary Layar aktif")
            .setContentText("Tap ikon di layar, atau pakai tombol di sini")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_media_play, "Mulai rekam", startPi)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        running = false
        if (listening) CaptureState.removeListener(this)
        bubbleView?.let {
            try { windowManager?.removeView(it) } catch (t: Throwable) { }
        }
        bubbleView = null
        super.onDestroy()
    }
}
