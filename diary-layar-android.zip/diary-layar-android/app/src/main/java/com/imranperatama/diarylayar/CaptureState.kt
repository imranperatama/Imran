package com.imranperatama.diarylayar

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/**
 * State bersama antara service rekam, bubble, dan layar utama.
 * Semua callback listener SELALU dijalankan di main thread,
 * jadi aman buat nyentuh View.
 */
object CaptureState {
    @Volatile var isCapturing: Boolean = false
    @Volatile var frameCount: Int = 0
    @Volatile var lastError: String? = null

    interface Listener {
        fun onCaptureStateChanged(capturing: Boolean, frameCount: Int)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    fun addListener(listener: Listener) {
        listeners.add(listener)
        mainHandler.post { listener.onCaptureStateChanged(isCapturing, frameCount) }
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    fun update(capturing: Boolean, count: Int) {
        isCapturing = capturing
        frameCount = count
        mainHandler.post {
            for (l in listeners) {
                l.onCaptureStateChanged(capturing, count)
            }
        }
    }
}
