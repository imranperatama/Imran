package com.imranperatama.diarylayar

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Activity transparan: cuma buat minta izin rekam layar dari ikon mengambang/notifikasi. */
class TrampolineActivity : ComponentActivity() {

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intervalMs = getSharedPreferences("diary_layar", MODE_PRIVATE)
                .getLong("interval_ms", 1000L)

            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
                putExtra(ScreenCaptureService.EXTRA_INTERVAL_MS, intervalMs)
            }
            try {
                ContextCompat.startForegroundService(this, serviceIntent)
            } catch (t: Throwable) {
                CaptureState.lastError = "Gagal start service: ${t.javaClass.simpleName}: ${t.message}"
                ScreenCaptureService.logLine(this, CaptureState.lastError ?: "")
            }
        } else {
            ScreenCaptureService.logLine(this, "Izin rekam layar dibatalkan dari ikon/notifikasi")
        }
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(pm.createScreenCaptureIntent())
        } catch (t: Throwable) {
            CaptureState.lastError = "Gagal minta izin rekam layar: ${t.javaClass.simpleName}: ${t.message}"
            ScreenCaptureService.logLine(this, CaptureState.lastError ?: "")
            finish()
        }
    }
}
