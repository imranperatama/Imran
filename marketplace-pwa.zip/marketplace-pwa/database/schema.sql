-- =====================================================================
-- Marketplace PWA — Database Schema (Tahap 1)
-- Target: Supabase PostgreSQL
-- Prinsip: integer (bukan float) untuk uang, ledger untuk saldo,
--          audit trail untuk perubahan status penting, idempotency key
--          di semua endpoint yang mengubah state finansial.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------
create extension if not exists "pgcrypto"; -- untuk gen_random_uuid()

-- ---------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------
create type user_role as enum ('buyer', 'seller', 'admin');

create type order_status as enum (
  'CREATED',
  'PAYMENT_PENDING',
  'PAYMENT_CONFIRMED',
  'ESCROW_HELD',
  'PROCESSING',
  'DELIVERED',
  'COMPLETED',
  'REFUND',
  'REFUNDED',
  'CANCELLED'
);

create type payment_status as enum ('PENDING', 'CONFIRMED', 'FAILED', 'EXPIRED');

create type escrow_status as enum ('HELD', 'RELEASED', 'REFUNDED');

create type wallet_tx_type as enum (
  'DEPOSIT',
  'ESCROW_HOLD',
  'ESCROW_RELEASE',
  'REFUND',
  'WITHDRAWAL',
  'ADJUSTMENT'
);

create type bot_job_status as enum (
  'PENDING', 'RUNNING', 'SUCCESS', 'FAILED', 'RETRY', 'MANUAL_REVIEW'
);

create type product_type as enum ('MANUAL', 'AUTOMATED');

-- ---------------------------------------------------------------------
-- Helper: trigger auto-update kolom updated_at
-- ---------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ---------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------
create table users (
  id            uuid primary key default gen_random_uuid(),
  email         varchar(255) not null unique,
  password_hash text not null,
  full_name     varchar(150),
  phone         varchar(30),
  role          user_role not null default 'buyer',
  is_active     boolean not null default true,
  is_verified   boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create trigger trg_users_updated_at
  before update on users
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- seller_profiles (1:1 dengan users yang berperan seller)
-- ---------------------------------------------------------------------
create table seller_profiles (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null unique references users(id) on delete cascade,
  store_name    varchar(150) not null,
  store_slug    varchar(160) not null unique,
  description   text,
  is_verified   boolean not null default false,
  rating_avg    numeric(3,2) not null default 0,
  total_sales   integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create trigger trg_seller_profiles_updated_at
  before update on seller_profiles
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- games
-- ---------------------------------------------------------------------
create table games (
  id          uuid primary key default gen_random_uuid(),
  name        varchar(120) not null,
  slug        varchar(140) not null unique,
  icon_url    text,
  banner_url  text,
  is_active   boolean not null default true,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create trigger trg_games_updated_at
  before update on games
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- categories
-- ---------------------------------------------------------------------
create table categories (
  id          uuid primary key default gen_random_uuid(),
  game_id     uuid not null references games(id) on delete cascade,
  name        varchar(120) not null,
  slug        varchar(140) not null,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (game_id, slug)
);

create index idx_categories_game_id on categories(game_id);

create trigger trg_categories_updated_at
  before update on categories
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- products
-- ---------------------------------------------------------------------
create table products (
  id             uuid primary key default gen_random_uuid(),
  seller_id      uuid not null references seller_profiles(id) on delete cascade,
  game_id        uuid not null references games(id),
  category_id    uuid not null references categories(id),
  name           varchar(200) not null,
  slug           varchar(220) not null,
  description    text,
  product_type   product_type not null default 'MANUAL',
  price_amount   bigint not null check (price_amount >= 0), -- integer rupiah
  currency       varchar(3) not null default 'IDR',
  thumbnail_url  text,
  is_active      boolean not null default true,
  metadata       jsonb not null default '{}',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (seller_id, slug)
);

create index idx_products_game_id on products(game_id);
create index idx_products_category_id on products(category_id);
create index idx_products_seller_id on products(seller_id);
create index idx_products_is_active on products(is_active);

create trigger trg_products_updated_at
  before update on products
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- product_stock
-- ---------------------------------------------------------------------
create table product_stock (
  id                  uuid primary key default gen_random_uuid(),
  product_id          uuid not null references products(id) on delete cascade,
  sku                 varchar(100),
  stock_type          varchar(20) not null default 'UNLIMITED', -- UNLIMITED | LIMITED | SERIAL
  quantity_available  integer not null default 0 check (quantity_available >= 0),
  quantity_reserved   integer not null default 0 check (quantity_reserved >= 0),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create index idx_product_stock_product_id on product_stock(product_id);

create trigger trg_product_stock_updated_at
  before update on product_stock
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- orders
-- ---------------------------------------------------------------------
create table orders (
  id               uuid primary key default gen_random_uuid(),
  order_number     varchar(40) not null unique,
  buyer_id         uuid not null references users(id),
  status           order_status not null default 'CREATED',
  total_amount     bigint not null check (total_amount >= 0),
  currency         varchar(3) not null default 'IDR',
  idempotency_key  varchar(100) not null unique,
  metadata         jsonb not null default '{}',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create index idx_orders_buyer_id on orders(buyer_id);
create index idx_orders_status on orders(status);

create trigger trg_orders_updated_at
  before update on orders
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- order_items
-- ---------------------------------------------------------------------
create table order_items (
  id                  uuid primary key default gen_random_uuid(),
  order_id            uuid not null references orders(id) on delete cascade,
  product_id          uuid not null references products(id),
  seller_id           uuid not null references seller_profiles(id),
  quantity            integer not null check (quantity > 0),
  unit_price          bigint not null check (unit_price >= 0),
  subtotal            bigint not null check (subtotal >= 0),
  delivery_reference  text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create index idx_order_items_order_id on order_items(order_id);
create index idx_order_items_seller_id on order_items(seller_id);

create trigger trg_order_items_updated_at
  before update on order_items
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- payments
-- ---------------------------------------------------------------------
create table payments (
  id                  uuid primary key default gen_random_uuid(),
  order_id            uuid not null references orders(id),
  provider            varchar(50) not null,          -- 'mock', 'midtrans', 'xendit', dst
  provider_reference  varchar(150),
  status              payment_status not null default 'PENDING',
  amount              bigint not null check (amount >= 0),
  idempotency_key     varchar(100) not null unique,
  raw_payload         jsonb,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create index idx_payments_order_id on payments(order_id);

create trigger trg_payments_updated_at
  before update on payments
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- escrow_transactions
-- ---------------------------------------------------------------------
create table escrow_transactions (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references orders(id),
  status        escrow_status not null default 'HELD',
  amount        bigint not null check (amount >= 0),
  held_at       timestamptz,
  released_at   timestamptz,
  refunded_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index idx_escrow_transactions_order_id on escrow_transactions(order_id);

create trigger trg_escrow_transactions_updated_at
  before update on escrow_transactions
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- wallets (1:1 dengan users)
-- ---------------------------------------------------------------------
create table wallets (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null unique references users(id) on delete cascade,
  balance     bigint not null default 0 check (balance >= 0), -- integer rupiah
  currency    varchar(3) not null default 'IDR',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create trigger trg_wallets_updated_at
  before update on wallets
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- wallet_transactions (ledger — sumber kebenaran untuk saldo)
-- ---------------------------------------------------------------------
create table wallet_transactions (
  id               uuid primary key default gen_random_uuid(),
  wallet_id        uuid not null references wallets(id),
  type             wallet_tx_type not null,
  amount           bigint not null,          -- positif = kredit, negatif = debit
  balance_before   bigint not null,
  balance_after    bigint not null,
  reference_type   varchar(30),              -- 'order' | 'refund' | 'withdrawal' | dst
  reference_id     uuid,
  idempotency_key  varchar(100) not null unique,
  created_at       timestamptz not null default now()
);

create index idx_wallet_transactions_wallet_id on wallet_transactions(wallet_id);
create index idx_wallet_transactions_reference on wallet_transactions(reference_type, reference_id);

-- ---------------------------------------------------------------------
-- refunds
-- ---------------------------------------------------------------------
create table refunds (
  id                     uuid primary key default gen_random_uuid(),
  order_id               uuid not null references orders(id),
  escrow_transaction_id  uuid references escrow_transactions(id),
  amount                 bigint not null check (amount >= 0),
  reason                 text,
  status                 varchar(20) not null default 'PENDING', -- PENDING | COMPLETED | REJECTED
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

create index idx_refunds_order_id on refunds(order_id);

create trigger trg_refunds_updated_at
  before update on refunds
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- notifications
-- ---------------------------------------------------------------------
create table notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references users(id) on delete cascade,
  type        varchar(50) not null,
  title       varchar(200) not null,
  body        text,
  is_read     boolean not null default false,
  metadata    jsonb not null default '{}',
  created_at  timestamptz not null default now()
);

create index idx_notifications_user_id_is_read on notifications(user_id, is_read);

-- ---------------------------------------------------------------------
-- bot_jobs (job untuk Python worker)
-- ---------------------------------------------------------------------
create table bot_jobs (
  id              uuid primary key default gen_random_uuid(),
  order_item_id   uuid not null references order_items(id),
  job_type        varchar(50) not null,
  status          bot_job_status not null default 'PENDING',
  payload         jsonb not null,
  result          jsonb,
  attempts        integer not null default 0,
  max_attempts    integer not null default 3,
  locked_by       varchar(100),
  locked_at       timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index idx_bot_jobs_status on bot_jobs(status);
create index idx_bot_jobs_order_item_id on bot_jobs(order_item_id);

create trigger trg_bot_jobs_updated_at
  before update on bot_jobs
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- audit_logs
-- ---------------------------------------------------------------------
create table audit_logs (
  id            uuid primary key default gen_random_uuid(),
  actor_type    varchar(20) not null,   -- 'user' | 'system' | 'worker'
  actor_id      uuid,
  entity_type   varchar(50) not null,   -- 'order' | 'wallet' | 'escrow' | dst
  entity_id     uuid not null,
  action        varchar(50) not null,
  before_state  jsonb,
  after_state   jsonb,
  ip_address    inet,
  created_at    timestamptz not null default now()
);

create index idx_audit_logs_entity on audit_logs(entity_type, entity_id);
create index idx_audit_logs_actor on audit_logs(actor_type, actor_id);

-- =====================================================================
-- Catatan implementasi (dipakai mulai Tahap 5 & 6):
--
-- 1. Perubahan saldo wallet WAJIB dalam satu transaction:
--      BEGIN;
--      SELECT balance FROM wallets WHERE id = $1 FOR UPDATE;
--      -- hitung balance_after di aplikasi
--      INSERT INTO wallet_transactions (...) VALUES (...);
--      UPDATE wallets SET balance = $balance_after WHERE id = $1;
--      COMMIT;
--
-- 2. idempotency_key pada orders/payments/wallet_transactions dicek
--    dengan `INSERT ... ON CONFLICT (idempotency_key) DO NOTHING`
--    lalu return baris yang sudah ada jika konflik — bukan error 500.
--
-- 3. Webhook payment (Tahap 6) memverifikasi signature SEBELUM
--    menyentuh tabel apapun.
-- =====================================================================
