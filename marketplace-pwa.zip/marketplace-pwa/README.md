# Marketplace PWA

Marketplace digital (mirip itemku) dengan escrow, wallet ledger, dan worker
bot otomatis. Dibangun bertahap (Tahap 1–10, lihat `docs/ARCHITECTURE.md`).

## Status: Semua 10 Tahap Selesai (Backend + Frontend + Worker)

- ✅ Tahap 1 — Blueprint & database schema (`docs/ARCHITECTURE.md`, `database/schema.sql`)
- ✅ Tahap 2 — Backend Node.js/Express skeleton (`apps/api`)
- ✅ Tahap 3 — Auth (JWT + Argon2) & RBAC
- ✅ Tahap 4 — Katalog produk (games/categories/products + manajemen seller)
- ✅ Tahap 5 — Order + escrow + wallet ledger
- ✅ Tahap 6 — Payment webhook (mock provider, signature HMAC + idempotency)
- ✅ Tahap 7 — Worker Python + job queue (`apps/worker`)
- ✅ Tahap 8 — Frontend PWA React + Vite (`apps/web`)
- ✅ Tahap 9 — Notifikasi realtime (Server-Sent Events)
- ✅ Tahap 10 — Testing contoh, security checklist, deployment notes

**Database sudah live di Supabase** (project `marketplace-pwa`, schema + RLS sudah diterapkan) — kamu tinggal isi `.env` masing-masing app dan jalankan.

## Cara Menjalankan (Development)

### 1. Backend
```bash
cd apps/api
cp .env.example .env   # isi DATABASE_URL dari Supabase Dashboard + generate semua secret
npm install
npm run dev             # jalan di http://localhost:4000
```

### 2. Frontend
```bash
cd apps/web
cp .env.example .env
npm install
npm run dev              # jalan di http://localhost:5173, proxy /api ke backend
```

### Deploy ke Netlify
Baca `docs/DEPLOYMENT.md` bagian "Deploy Frontend ke Netlify" — proyek ini
monorepo jadi butuh setting base directory + `VITE_API_BASE_URL` di
dashboard Netlify. `netlify.toml` + `public/_redirects` (SPA fallback)
sudah disediakan.

### 3. Worker (opsional — hanya perlu untuk produk `AUTOMATED`)
```bash
cd apps/worker
cp .env.example .env    # WORKER_API_KEY harus sama dengan di apps/api/.env
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
playwright install chromium
python main.py
```

## Testing
```bash
cd apps/api
npm test                 # node --test tests/  (butuh DATABASE_URL aktif untuk sebagian test)
```

## Dokumen Penting

- `docs/ARCHITECTURE.md` — blueprint arsitektur & state machine
- `docs/SECURITY_CHECKLIST.md` — status tiap item keamanan + yang wajib diganti sebelum production
- `docs/DEPLOYMENT.md` — cara deploy backend/frontend/worker + PWA checklist
- `database/schema.sql` — schema lengkap (sudah diterapkan ke Supabase)

## Yang Masih Perlu Kamu Putuskan/Isi Sendiri

1. **Payment gateway asli** — ganti `apps/api/src/providers/mockPaymentProvider.js` dengan SDK Midtrans/Xendit/dll.
2. **Logika Playwright asli** — isi `apps/worker/bot/topup_bot.py` sesuai provider topup yang dipakai (saat ini stub).
3. **Icon PWA** — placeholder sudah dibuat (`apps/web/public/icons/icon-192.png` & `icon-512.png`, warna ungu + huruf "M"), ganti dengan logo asli kalau sudah ada.
4. **Semua secret di `.env`** — jangan pakai nilai contoh di `.env.example` untuk production.
5. **Flow refund** — tabel sudah ada, endpoint approval/otomatisasinya belum diimplementasi (butuh keputusan bisnis).
