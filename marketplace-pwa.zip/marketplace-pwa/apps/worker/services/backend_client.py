"""
Satu-satunya cara worker bicara dengan backend Node.js. Semua request
disertai header X-Worker-Key (autentikasi) dan X-Worker-Id (identitas
untuk locking job). Worker TIDAK PERNAH mengakses database secara
langsung — ini prinsip keamanan inti dari arsitektur (lihat
docs/ARCHITECTURE.md §2 & §4): worker cuma boleh bicara lewat REST API.
"""
from __future__ import annotations

import requests
from tenacity import retry, stop_after_attempt, wait_exponential

from config import settings

_session = requests.Session()
_session.headers.update(
    {
        "X-Worker-Key": settings.WORKER_API_KEY,
        "X-Worker-Id": settings.WORKER_ID,
        "Content-Type": "application/json",
    }
)


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=10))
def fetch_next_job() -> dict | None:
    """Minta job PENDING berikutnya. Backend mengunci job ini (SKIP LOCKED)
    supaya worker instance lain tidak mengambil job yang sama."""
    resp = _session.get(f"{settings.BACKEND_BASE_URL}/worker/jobs/next", timeout=10)
    resp.raise_for_status()
    return resp.json().get("data")


@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=1, max=15))
def report_job_result(job_id: str, status: str, result: dict, idempotency_key: str) -> dict:
    """Laporkan hasil job (SUCCESS/FAILED) ke backend. idempotency_key
    mencegah laporan dobel kalau request retry akibat network error —
    backend akan mengabaikan laporan kedua untuk key yang sama."""
    resp = _session.post(
        f"{settings.BACKEND_BASE_URL}/worker/jobs/{job_id}/result",
        json={"status": status, "result": result},
        headers={"Idempotency-Key": idempotency_key},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json().get("data")
