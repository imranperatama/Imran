"""
Konfigurasi worker, dibaca dari environment variables (.env).
Fail fast: kalau ada var wajib yang hilang, proses langsung berhenti
saat start, bukan gagal diam-diam di tengah polling loop.
"""
import os
import sys
from dotenv import load_dotenv

load_dotenv()

REQUIRED_VARS = ["BACKEND_BASE_URL", "WORKER_API_KEY"]

_missing = [name for name in REQUIRED_VARS if not os.getenv(name)]
if _missing:
    print(f"[FATAL] Environment variable hilang: {', '.join(_missing)}", file=sys.stderr)
    sys.exit(1)

BACKEND_BASE_URL = os.getenv("BACKEND_BASE_URL")
WORKER_API_KEY = os.getenv("WORKER_API_KEY")
WORKER_ID = os.getenv("WORKER_ID", "worker-01")
POLL_INTERVAL_SECONDS = float(os.getenv("POLL_INTERVAL_SECONDS", "3"))

PROVIDER_LOGIN_USERNAME = os.getenv("PROVIDER_LOGIN_USERNAME", "")
PROVIDER_LOGIN_PASSWORD = os.getenv("PROVIDER_LOGIN_PASSWORD", "")
