"""
Bot Playwright untuk memproses topup digital otomatis.

INI STUB/CONTOH — ganti selector & logika sesuai provider topup asli
yang dipakai (mis. panel reseller pulsa/e-wallet tertentu). Struktur
fungsi (login -> submit order -> baca hasil) dipertahankan supaya
main.py tidak perlu berubah saat implementasi asli diisi.
"""
from __future__ import annotations

from playwright.sync_api import sync_playwright

from config import settings


class TopupBotError(Exception):
    pass


def process_topup_job(payload: dict) -> dict:
    """
    payload berisi apa yang dikirim backend saat membuat bot_jobs, mis:
    {"orderId": "...", "orderItemId": "..."}

    Return dict berisi minimal `deliveryReference` kalau sukses.
    Raise TopupBotError kalau gagal (akan ditangkap main.py -> lapor FAILED).
    """
    order_item_id = payload.get("orderItemId")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        try:
            # --- CONTOH ALUR, SESUAIKAN DENGAN PROVIDER ASLI ---
            # page.goto("https://provider-topup.example.com/login")
            # page.fill("#username", settings.PROVIDER_LOGIN_USERNAME)
            # page.fill("#password", settings.PROVIDER_LOGIN_PASSWORD)
            # page.click("#login-button")
            # page.wait_for_selector("#dashboard")
            #
            # page.goto(f"https://provider-topup.example.com/order/{order_item_id}")
            # page.click("#submit-topup")
            # page.wait_for_selector(".result-success, .result-failed", timeout=30000)
            #
            # if page.is_visible(".result-failed"):
            #     reason = page.inner_text(".result-failed .reason")
            #     raise TopupBotError(f"Provider menolak order: {reason}")
            #
            # reference = page.inner_text(".result-success .reference-code")
            # return {"deliveryReference": reference}

            raise TopupBotError(
                "topup_bot.py masih berupa stub — isi langkah Playwright "
                "sesuai provider topup asli sebelum dipakai di produksi."
            )
        finally:
            browser.close()
