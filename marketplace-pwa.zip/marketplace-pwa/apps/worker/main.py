"""
Entry point worker: polling loop sederhana.

Alur (sesuai docs/ARCHITECTURE.md §3):
  1. Minta job PENDING berikutnya ke backend (backend yang mengunci job).
  2. Kalau tidak ada job, tidur sebentar, polling lagi.
  3. Kalau ada job, jalankan bot sesuai job_type.
  4. Laporkan hasil (SUCCESS/FAILED) ke backend — backend yang menentukan
     efeknya ke saldo/status order, worker TIDAK PERNAH mengubah itu sendiri.
"""
from __future__ import annotations

import time
import signal
import sys

from config import settings
from services.backend_client import fetch_next_job, report_job_result
from bot.topup_bot import process_topup_job, TopupBotError

_running = True


def _handle_shutdown(signum, frame):
    global _running
    print(f"[worker] Menerima signal {signum}, berhenti setelah job saat ini selesai...")
    _running = False


signal.signal(signal.SIGINT, _handle_shutdown)
signal.signal(signal.SIGTERM, _handle_shutdown)


JOB_HANDLERS = {
    "DIGITAL_TOPUP": process_topup_job,
}


def handle_job(job: dict) -> None:
    job_id = job["id"]
    job_type = job["job_type"]
    payload = job.get("payload") or {}

    handler = JOB_HANDLERS.get(job_type)
    if handler is None:
        print(f"[worker] Job type '{job_type}' tidak dikenal, tandai FAILED")
        report_job_result(job_id, "FAILED", {"error": f"Unknown job_type {job_type}"}, f"{job_id}:unknown-type")
        return

    idempotency_key = f"{job_id}:{job_type}:result"
    try:
        result = handler(payload)
        print(f"[worker] Job {job_id} SUKSES: {result}")
        report_job_result(job_id, "SUCCESS", result, idempotency_key)
    except TopupBotError as e:
        print(f"[worker] Job {job_id} GAGAL: {e}")
        report_job_result(job_id, "FAILED", {"error": str(e)}, idempotency_key)
    except Exception as e:  # noqa: BLE001 - sengaja tangkap semua supaya worker tidak crash total
        print(f"[worker] Job {job_id} ERROR TAK TERDUGA: {e}")
        report_job_result(job_id, "FAILED", {"error": f"Unexpected error: {e}"}, idempotency_key)


def main() -> None:
    print(f"[worker] {settings.WORKER_ID} mulai polling {settings.BACKEND_BASE_URL}")
    while _running:
        try:
            job = fetch_next_job()
        except Exception as e:  # noqa: BLE001
            print(f"[worker] Gagal fetch job (network/backend down?): {e}")
            time.sleep(settings.POLL_INTERVAL_SECONDS)
            continue

        if job is None:
            time.sleep(settings.POLL_INTERVAL_SECONDS)
            continue

        handle_job(job)

    print("[worker] Berhenti dengan aman.")
    sys.exit(0)


if __name__ == "__main__":
    main()
