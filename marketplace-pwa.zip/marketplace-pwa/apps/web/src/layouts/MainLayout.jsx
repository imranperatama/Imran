import { Outlet } from "react-router-dom";
import Header from "../components/Header.jsx";
import BottomNav from "../components/BottomNav.jsx";

export default function MainLayout() {
  return (
    <div className="min-h-screen pb-16">
      <Header />
      <main className="mx-auto max-w-lg px-4 py-4">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}
