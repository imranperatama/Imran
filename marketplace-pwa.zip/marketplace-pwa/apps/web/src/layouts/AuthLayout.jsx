import { Outlet, Navigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.jsx";

// Bungkus route yang wajib login. Kalau belum login, lempar ke /login
// (setelah proses silent-refresh awal selesai, supaya tidak "kedip"
// redirect ke login padahal sebenarnya sesi masih valid).
export default function AuthLayout() {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Memuat...</div>;
  }
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <Outlet />;
}
