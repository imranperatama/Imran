import { Outlet, Navigate, NavLink } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.jsx";

export default function SellerLayout() {
  const { user, loading } = useAuth();

  if (loading) return <div className="p-8 text-center text-slate-400">Memuat...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== "seller") {
    return <Navigate to="/" replace />;
  }

  const tabs = [
    { to: "/seller", label: "Dashboard", end: true },
    { to: "/seller/products", label: "Produk" },
    { to: "/seller/orders", label: "Pesanan" },
    { to: "/seller/wallet", label: "Wallet" },
  ];

  return (
    <div className="pb-20">
      <nav className="mb-4 flex gap-2 overflow-x-auto border-b border-slate-800 pb-2">
        {tabs.map((t) => (
          <NavLink
            key={t.to}
            to={t.to}
            end={t.end}
            className={({ isActive }) =>
              `whitespace-nowrap rounded-full px-3 py-1 text-sm ${
                isActive ? "bg-brand text-white" : "bg-slate-900 text-slate-300"
              }`
            }
          >
            {t.label}
          </NavLink>
        ))}
      </nav>
      <Outlet />
    </div>
  );
}
