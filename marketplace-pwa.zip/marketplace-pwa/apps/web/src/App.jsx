import { Routes, Route } from "react-router-dom";

import MainLayout from "./layouts/MainLayout.jsx";
import AuthLayout from "./layouts/AuthLayout.jsx";
import SellerLayout from "./layouts/SellerLayout.jsx";

import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import GameList from "./pages/GameList.jsx";
import GameDetail from "./pages/GameDetail.jsx";
import ProductDetail from "./pages/ProductDetail.jsx";
import Cart from "./pages/Cart.jsx";
import Checkout from "./pages/Checkout.jsx";
import Pay from "./pages/Pay.jsx";
import Orders from "./pages/Orders.jsx";
import OrderDetail from "./pages/OrderDetail.jsx";
import Wallet from "./pages/Wallet.jsx";
import Notifications from "./pages/Notifications.jsx";
import Profile from "./pages/Profile.jsx";

import SellerDashboard from "./pages/seller/SellerDashboard.jsx";
import SellerProducts from "./pages/seller/SellerProducts.jsx";
import SellerProductForm from "./pages/seller/SellerProductForm.jsx";
import SellerOrders from "./pages/seller/SellerOrders.jsx";
import SellerWallet from "./pages/seller/SellerWallet.jsx";

export default function App() {
  return (
    <Routes>
      {/* Halaman login/register tanpa BottomNav */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route element={<MainLayout />}>
        {/* Publik */}
        <Route path="/" element={<Home />} />
        <Route path="/games" element={<GameList />} />
        <Route path="/games/:slug" element={<GameDetail />} />
        <Route path="/products/:id" element={<ProductDetail />} />
        <Route path="/profile" element={<Profile />} />

        {/* Wajib login (buyer) */}
        <Route element={<AuthLayout />}>
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/pay/:paymentId" element={<Pay />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/orders/:id" element={<OrderDetail />} />
          <Route path="/wallet" element={<Wallet />} />
          <Route path="/notifications" element={<Notifications />} />
        </Route>

        {/* Wajib login + role seller */}
        <Route path="/seller" element={<SellerLayout />}>
          <Route index element={<SellerDashboard />} />
          <Route path="products" element={<SellerProducts />} />
          <Route path="products/new" element={<SellerProductForm />} />
          <Route path="orders" element={<SellerOrders />} />
          <Route path="wallet" element={<SellerWallet />} />
        </Route>
      </Route>

      <Route path="*" element={<div className="p-8 text-center text-slate-400">Halaman tidak ditemukan</div>} />
    </Routes>
  );
}
