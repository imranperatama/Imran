import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { Search, Bell, CircleUserRound } from "lucide-react";

export default function Header() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  function onSearch(e) {
    e.preventDefault();
    navigate(q ? `/games?q=${encodeURIComponent(q)}` : "/games");
  }

  return (
    <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/90 px-4 py-3 backdrop-blur-lg">
      <div className="mx-auto flex max-w-lg items-center gap-3">
        <Link to="/" className="text-lg font-bold tracking-tight text-brand">
          Marketplace
        </Link>
        <form onSubmit={onSearch} className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari game atau produk..."
            className="w-full rounded-full bg-slate-900 py-2 pl-9 pr-4 text-sm outline-none ring-1 ring-slate-800 transition-shadow focus:ring-2 focus:ring-brand"
          />
        </form>
        <Link to="/notifications" aria-label="Notifikasi" className="text-slate-300 hover:text-white">
          <Bell size={22} strokeWidth={1.8} />
        </Link>
        <Link to="/profile" aria-label="Profil" className="text-slate-300 hover:text-white">
          <CircleUserRound size={22} strokeWidth={1.8} />
        </Link>
      </div>
    </header>
  );
}
