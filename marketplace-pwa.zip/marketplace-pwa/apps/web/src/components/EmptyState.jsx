import { Inbox } from "lucide-react";

export default function EmptyState({ title, description, action, icon: Icon = Inbox }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center text-slate-400">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-900 text-slate-500">
        <Icon size={26} strokeWidth={1.6} />
      </div>
      <div>
        <p className="font-medium text-slate-200">{title}</p>
        {description && <p className="mt-1 text-sm">{description}</p>}
      </div>
      {action}
    </div>
  );
}
