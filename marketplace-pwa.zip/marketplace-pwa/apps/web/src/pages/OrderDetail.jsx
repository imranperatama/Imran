import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";

const STEPS = ["CREATED", "PAYMENT_CONFIRMED", "ESCROW_HELD", "PROCESSING", "DELIVERED", "COMPLETED"];

export default function OrderDetail() {
  const { id } = useParams();
  const orderQuery = useQuery({
    queryKey: ["order", id],
    queryFn: () => api.get(`/orders/${id}`),
    refetchInterval: 5000, // polling ringan sebagai fallback selain SSE notification
  });

  if (orderQuery.isLoading) return <Skeleton className="h-64" />;
  if (orderQuery.isError) return <p className="text-red-400">Order tidak ditemukan.</p>;

  const order = orderQuery.data;
  const currentStepIndex = STEPS.indexOf(order.status);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-lg font-semibold">{order.order_number}</h1>
        <p className="text-sm text-slate-400">
          {new Date(order.created_at).toLocaleString("id-ID")}
        </p>
      </div>

      {currentStepIndex >= 0 && (
        <div className="flex items-center gap-1">
          {STEPS.map((step, i) => (
            <div key={step} className="flex flex-1 items-center gap-1">
              <div
                className={`h-2 flex-1 rounded-full ${
                  i <= currentStepIndex ? "bg-brand" : "bg-slate-800"
                }`}
              />
            </div>
          ))}
        </div>
      )}
      <p className="text-sm text-slate-300">Status: {order.status}</p>

      <div className="rounded-xl bg-slate-900 p-4">
        {order.items.map((item) => (
          <div key={item.id} className="flex justify-between py-1 text-sm">
            <span>
              {item.product_name} × {item.quantity}
            </span>
            <span>Rp{Number(item.subtotal).toLocaleString("id-ID")}</span>
          </div>
        ))}
        <div className="mt-2 flex justify-between border-t border-slate-800 pt-2 font-semibold">
          <span>Total</span>
          <span>Rp{Number(order.total_amount).toLocaleString("id-ID")}</span>
        </div>
      </div>

      {order.items.some((i) => i.delivery_reference) && (
        <div className="rounded-xl bg-slate-900 p-4 text-sm">
          <p className="mb-1 text-slate-400">Kode pengiriman:</p>
          {order.items
            .filter((i) => i.delivery_reference)
            .map((i) => (
              <p key={i.id} className="font-mono text-brand">
                {i.delivery_reference}
              </p>
            ))}
        </div>
      )}
    </div>
  );
}
