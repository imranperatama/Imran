import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "../services/api.js";
import { useNotificationsStream } from "../hooks/useNotificationsStream.js";
import Skeleton from "../components/Skeleton.jsx";
import EmptyState from "../components/EmptyState.jsx";

export default function Notifications() {
  const queryClient = useQueryClient();
  const notifQuery = useQuery({ queryKey: ["notifications"], queryFn: () => api.get("/notifications") });

  useNotificationsStream(() => {
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
  });

  const readMutation = useMutation({
    mutationFn: (id) => api.patch(`/notifications/${id}/read`, {}),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  if (notifQuery.isLoading) {
    return (
      <div className="flex flex-col gap-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16" />
        ))}
      </div>
    );
  }

  if (notifQuery.data.length === 0) {
    return <EmptyState title="Belum ada notifikasi" />;
  }

  return (
    <div className="flex flex-col gap-2">
      <h1 className="mb-2 text-lg font-semibold">Notifikasi</h1>
      {notifQuery.data.map((n) => (
        <button
          key={n.id}
          onClick={() => !n.is_read && readMutation.mutate(n.id)}
          className={`rounded-xl p-3 text-left ${n.is_read ? "bg-slate-900" : "bg-slate-800 ring-1 ring-brand"}`}
        >
          <p className="text-sm font-medium">{n.title}</p>
          {n.body && <p className="text-sm text-slate-400">{n.body}</p>}
          <p className="mt-1 text-xs text-slate-500">{new Date(n.created_at).toLocaleString("id-ID")}</p>
        </button>
      ))}
    </div>
  );
}
