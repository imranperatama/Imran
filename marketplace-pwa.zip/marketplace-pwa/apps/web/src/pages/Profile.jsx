import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.jsx";

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/login");
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <p className="text-slate-400">Kamu belum masuk</p>
        <Link to="/login" className="rounded-lg bg-brand px-6 py-2 text-sm text-white">
          Masuk
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-xl bg-slate-900 p-4">
        <p className="text-lg font-semibold">{user.email}</p>
        <p className="text-sm capitalize text-slate-400">Role: {user.role}</p>
      </div>

      <div className="flex flex-col overflow-hidden rounded-xl bg-slate-900">
        <Link to="/orders" className="border-b border-slate-800 p-4 text-sm">
          Pesanan Saya
        </Link>
        <Link to="/wallet" className="border-b border-slate-800 p-4 text-sm">
          Wallet
        </Link>
        {user.role === "seller" && (
          <Link to="/seller" className="border-b border-slate-800 p-4 text-sm">
            Dashboard Seller
          </Link>
        )}
        <Link to="/notifications" className="p-4 text-sm">
          Notifikasi
        </Link>
      </div>

      <button onClick={handleLogout} className="rounded-lg bg-slate-900 py-3 text-sm text-red-400">
        Keluar
      </button>
    </div>
  );
}
