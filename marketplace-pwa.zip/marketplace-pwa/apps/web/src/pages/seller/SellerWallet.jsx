import { useQuery } from "@tanstack/react-query";
import { api } from "../../services/api.js";
import Skeleton from "../../components/Skeleton.jsx";
import EmptyState from "../../components/EmptyState.jsx";

const TYPE_LABEL = {
  DEPOSIT: "Deposit",
  ESCROW_HOLD: "Dana Ditahan",
  ESCROW_RELEASE: "Dana Diterima",
  REFUND: "Refund",
  WITHDRAWAL: "Penarikan",
  ADJUSTMENT: "Penyesuaian",
};

export default function SellerWallet() {
  const walletQuery = useQuery({ queryKey: ["seller", "wallet"], queryFn: () => api.get("/seller/wallet") });
  const txQuery = useQuery({
    queryKey: ["seller", "wallet", "transactions"],
    queryFn: () => api.get("/seller/wallet/transactions"),
  });

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark p-6">
        <p className="text-sm text-white/80">Saldo Toko</p>
        {walletQuery.isLoading ? (
          <Skeleton className="mt-2 h-8 w-32 bg-white/20" />
        ) : (
          <p className="mt-1 text-2xl font-bold text-white">
            Rp{Number(walletQuery.data.balance).toLocaleString("id-ID")}
          </p>
        )}
      </div>

      <h2 className="font-semibold">Riwayat</h2>
      {txQuery.isLoading ? (
        <Skeleton className="h-24" />
      ) : txQuery.data.length === 0 ? (
        <EmptyState title="Belum ada transaksi" />
      ) : (
        <div className="flex flex-col gap-2">
          {txQuery.data.map((tx) => (
            <div key={tx.id} className="flex items-center justify-between rounded-xl bg-slate-900 p-3">
              <p className="text-sm">{TYPE_LABEL[tx.type] || tx.type}</p>
              <span className={`text-sm font-semibold ${tx.amount >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {tx.amount >= 0 ? "+" : ""}
                Rp{Number(tx.amount).toLocaleString("id-ID")}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
