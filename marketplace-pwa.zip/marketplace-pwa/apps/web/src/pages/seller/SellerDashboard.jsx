import { useQuery } from "@tanstack/react-query";
import { api } from "../../services/api.js";
import Skeleton from "../../components/Skeleton.jsx";

export default function SellerDashboard() {
  const walletQuery = useQuery({ queryKey: ["seller", "wallet"], queryFn: () => api.get("/seller/wallet") });
  const ordersQuery = useQuery({ queryKey: ["seller", "orders"], queryFn: () => api.get("/seller/orders") });
  const productsQuery = useQuery({
    queryKey: ["seller", "products"],
    queryFn: () => api.get("/seller/products"),
  });

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark p-6">
        <p className="text-sm text-white/80">Saldo Toko</p>
        {walletQuery.isLoading ? (
          <Skeleton className="mt-2 h-8 w-32 bg-white/20" />
        ) : (
          <p className="mt-1 text-2xl font-bold text-white">
            Rp{Number(walletQuery.data.balance).toLocaleString("id-ID")}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-slate-900 p-4">
          <p className="text-xs text-slate-400">Total Produk</p>
          <p className="text-xl font-bold">{productsQuery.data?.length ?? "-"}</p>
        </div>
        <div className="rounded-xl bg-slate-900 p-4">
          <p className="text-xs text-slate-400">Total Pesanan</p>
          <p className="text-xl font-bold">{ordersQuery.data?.length ?? "-"}</p>
        </div>
      </div>
    </div>
  );
}
