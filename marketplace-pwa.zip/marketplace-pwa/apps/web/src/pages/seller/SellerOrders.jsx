import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { api } from "../../services/api.js";
import Skeleton from "../../components/Skeleton.jsx";
import EmptyState from "../../components/EmptyState.jsx";

export default function SellerOrders() {
  const ordersQuery = useQuery({ queryKey: ["seller", "orders"], queryFn: () => api.get("/seller/orders") });

  if (ordersQuery.isLoading) return <Skeleton className="h-40" />;
  if (ordersQuery.data.length === 0) return <EmptyState title="Belum ada pesanan masuk" />;

  return (
    <div className="flex flex-col gap-2">
      <h1 className="mb-1 text-lg font-semibold">Pesanan Masuk</h1>
      {ordersQuery.data.map((o) => (
        <Link key={o.id} to={`/orders/${o.id}`} className="rounded-xl bg-slate-900 p-3">
          <div className="flex justify-between text-sm">
            <span className="font-medium">{o.order_number}</span>
            <span className="text-slate-400">{o.status}</span>
          </div>
          <p className="mt-1 text-sm text-brand">Rp{Number(o.subtotal).toLocaleString("id-ID")}</p>
        </Link>
      ))}
    </div>
  );
}
