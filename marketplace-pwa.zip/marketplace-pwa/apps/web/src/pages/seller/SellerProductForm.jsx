import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "../../services/api.js";

export default function SellerProductForm() {
  const navigate = useNavigate();
  const gamesQuery = useQuery({ queryKey: ["games"], queryFn: () => api.get("/games") });
  const [form, setForm] = useState({
    gameId: "",
    categoryId: "",
    name: "",
    description: "",
    productType: "MANUAL",
    priceAmount: "",
    initialStock: "0",
  });
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState("");

  async function onGameChange(gameId) {
    setForm((f) => ({ ...f, gameId, categoryId: "" }));
    if (!gameId) return setCategories([]);
    const slug = gamesQuery.data.find((g) => g.id === gameId)?.slug;
    const detail = await api.get(`/games/${slug}`);
    setCategories(detail.categories);
  }

  const createMutation = useMutation({
    mutationFn: () =>
      api.post("/seller/products", {
        ...form,
        priceAmount: Number(form.priceAmount),
        initialStock: Number(form.initialStock),
      }),
    onSuccess: () => navigate("/seller/products"),
    onError: (err) => setError(err.message),
  });

  return (
    <div className="flex flex-col gap-3">
      <h1 className="text-lg font-semibold">Tambah Produk</h1>

      <select
        value={form.gameId}
        onChange={(e) => onGameChange(e.target.value)}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800"
      >
        <option value="">Pilih Game</option>
        {gamesQuery.data?.map((g) => (
          <option key={g.id} value={g.id}>
            {g.name}
          </option>
        ))}
      </select>

      <select
        value={form.categoryId}
        onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
        disabled={!categories.length}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800 disabled:opacity-50"
      >
        <option value="">Pilih Kategori</option>
        {categories.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>

      <input
        placeholder="Nama produk"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800"
      />

      <textarea
        placeholder="Deskripsi (opsional)"
        value={form.description}
        onChange={(e) => setForm({ ...form, description: e.target.value })}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800"
        rows={3}
      />

      <div className="flex gap-2">
        {["MANUAL", "AUTOMATED"].map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setForm({ ...form, productType: t })}
            className={`flex-1 rounded-lg py-2 text-sm ${
              form.productType === t ? "bg-brand text-white" : "bg-slate-900 text-slate-300"
            }`}
          >
            {t === "MANUAL" ? "Manual" : "Otomatis (Bot)"}
          </button>
        ))}
      </div>

      <input
        type="number"
        min="0"
        placeholder="Harga (Rp)"
        value={form.priceAmount}
        onChange={(e) => setForm({ ...form, priceAmount: e.target.value })}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800"
      />

      <input
        type="number"
        min="0"
        placeholder="Stok awal (0 = tidak terbatas)"
        value={form.initialStock}
        onChange={(e) => setForm({ ...form, initialStock: e.target.value })}
        className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800"
      />

      {error && <p className="text-sm text-red-400">{error}</p>}

      <button
        disabled={createMutation.isPending || !form.gameId || !form.categoryId || !form.name || !form.priceAmount}
        onClick={() => createMutation.mutate()}
        className="rounded-lg bg-brand py-3 font-medium text-white disabled:opacity-50"
      >
        {createMutation.isPending ? "Menyimpan..." : "Simpan Produk"}
      </button>
    </div>
  );
}
