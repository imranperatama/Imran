import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { api } from "../../services/api.js";
import Skeleton from "../../components/Skeleton.jsx";
import EmptyState from "../../components/EmptyState.jsx";

export default function SellerProducts() {
  const productsQuery = useQuery({
    queryKey: ["seller", "products"],
    queryFn: () => api.get("/seller/products"),
  });

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Produk Saya</h1>
        <Link to="/seller/products/new" className="rounded-lg bg-brand px-3 py-1.5 text-sm text-white">
          + Tambah
        </Link>
      </div>

      {productsQuery.isLoading ? (
        <Skeleton className="h-40" />
      ) : productsQuery.data.length === 0 ? (
        <EmptyState title="Belum ada produk" description="Tambahkan produk pertamamu" />
      ) : (
        <div className="flex flex-col gap-2">
          {productsQuery.data.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-xl bg-slate-900 p-3">
              <div>
                <p className="text-sm font-medium">{p.name}</p>
                <p className="text-sm text-brand">Rp{Number(p.price_amount).toLocaleString("id-ID")}</p>
              </div>
              <span className={`text-xs ${p.is_active ? "text-emerald-400" : "text-slate-500"}`}>
                {p.is_active ? "Aktif" : "Nonaktif"}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
