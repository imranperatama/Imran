import { useQuery } from "@tanstack/react-query";
import { Link, useSearchParams } from "react-router-dom";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";
import EmptyState from "../components/EmptyState.jsx";

export default function GameList() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";

  const productsQuery = useQuery({
    queryKey: ["products", "search", q],
    queryFn: () => api.get(`/products${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  });

  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold">{q ? `Hasil untuk "${q}"` : "Semua Produk"}</h1>
      {productsQuery.isLoading ? (
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : productsQuery.data.items.length === 0 ? (
        <EmptyState title="Tidak ada produk ditemukan" />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {productsQuery.data.items.map((p) => (
            <Link key={p.id} to={`/products/${p.id}`} className="rounded-xl bg-slate-900 p-3">
              <div className="mb-2 aspect-video rounded-lg bg-slate-800" />
              <p className="line-clamp-1 text-sm font-medium">{p.name}</p>
              <p className="mt-1 text-sm font-semibold text-brand">
                Rp{Number(p.price_amount).toLocaleString("id-ID")}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
