import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";

export default function Home() {
  const gamesQuery = useQuery({ queryKey: ["games"], queryFn: () => api.get("/games") });
  const productsQuery = useQuery({
    queryKey: ["products", "popular"],
    queryFn: () => api.get("/products?pageSize=8"),
  });

  return (
    <div className="flex flex-col gap-6">
      {/* Hero Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark p-6">
        <p className="text-sm text-white/80">Top-up game & produk digital</p>
        <h1 className="mt-1 text-xl font-bold text-white">Cepat, aman, dengan rekber bawaan</h1>
      </div>

      {/* Game Categories */}
      <section>
        <h2 className="mb-3 font-semibold">Kategori Game</h2>
        {gamesQuery.isLoading ? (
          <div className="grid grid-cols-4 gap-3">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="aspect-square" />
            ))}
          </div>
        ) : gamesQuery.isError ? (
          <p className="text-sm text-red-400">Gagal memuat game.</p>
        ) : (
          <div className="grid grid-cols-4 gap-3">
            {gamesQuery.data.map((game) => (
              <Link
                key={game.id}
                to={`/games/${game.slug}`}
                className="flex flex-col items-center gap-1 rounded-xl bg-slate-900 p-2 text-center"
              >
                <div className="aspect-square w-full rounded-lg bg-slate-800" />
                <span className="line-clamp-1 text-xs">{game.name}</span>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Popular Products */}
      <section>
        <h2 className="mb-3 font-semibold">Produk Populer</h2>
        {productsQuery.isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        ) : productsQuery.isError ? (
          <p className="text-sm text-red-400">Gagal memuat produk.</p>
        ) : productsQuery.data.items.length === 0 ? (
          <p className="text-sm text-slate-400">Belum ada produk.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {productsQuery.data.items.map((p) => (
              <Link key={p.id} to={`/products/${p.id}`} className="rounded-xl bg-slate-900 p-3">
                <div className="mb-2 aspect-video rounded-lg bg-slate-800" />
                <p className="line-clamp-1 text-sm font-medium">{p.name}</p>
                <p className="text-xs text-slate-400">{p.game_name}</p>
                <p className="mt-1 text-sm font-semibold text-brand">
                  Rp{Number(p.price_amount).toLocaleString("id-ID")}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
