import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { ShieldCheck } from "lucide-react";
import { useCart } from "../hooks/useCart.jsx";
import { api, newIdempotencyKey } from "../services/api.js";
import EmptyState from "../components/EmptyState.jsx";

/**
 * PENTING: form ini HANYA mengirim productId + quantity ke backend.
 * Nominal yang tampil di sini murni untuk UX — backend menghitung ulang
 * harga asli dari database saat order dibuat, jadi tidak mungkin
 * dimanipulasi lewat DevTools/network tab. Setelah order+payment dibuat,
 * user langsung diarahkan ke halaman bayar (Pay.jsx) — tidak ada input
 * nominal manual di mana pun di alur ini.
 */
export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [error, setError] = useState("");

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      const orderKey = newIdempotencyKey();
      const order = await api.post(
        "/orders",
        { items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })) },
        { "Idempotency-Key": orderKey }
      );

      const paymentKey = newIdempotencyKey();
      const payment = await api.post(
        "/payments",
        { orderId: order.id },
        { "Idempotency-Key": paymentKey }
      );

      return payment;
    },
    onSuccess: (payment) => {
      clearCart();
      navigate(`/pay/${payment.id}`, { replace: true });
    },
    onError: (err) => setError(err.message),
  });

  if (items.length === 0) {
    return <EmptyState title="Keranjang kosong" description="Tidak ada yang bisa di-checkout" />;
  }

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-semibold">Checkout</h1>

      <div className="rounded-2xl bg-slate-900 p-4 ring-1 ring-slate-800">
        {items.map((item) => (
          <div key={item.productId} className="flex justify-between py-1 text-sm">
            <span className="line-clamp-1">
              {item.name} × {item.quantity}
            </span>
            <span>Rp{(item.priceAmount * item.quantity).toLocaleString("id-ID")}</span>
          </div>
        ))}
        <div className="mt-2 flex justify-between border-t border-slate-800 pt-2 font-semibold">
          <span>Total</span>
          <span>Rp{total.toLocaleString("id-ID")}</span>
        </div>
      </div>

      <div className="flex items-start gap-2 rounded-2xl bg-slate-900 p-4 text-sm text-slate-400 ring-1 ring-slate-800">
        <ShieldCheck size={18} className="mt-0.5 shrink-0 text-brand" />
        Dana akan ditahan di sistem rekber (escrow) sampai produk berhasil dikirim/diproses. Setelah ini
        kamu langsung diarahkan ke halaman bayar e-wallet — nominal sudah otomatis terisi.
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <button
        disabled={createOrderMutation.isPending}
        onClick={() => createOrderMutation.mutate()}
        className="rounded-xl bg-brand py-3.5 font-medium text-white disabled:opacity-50"
      >
        {createOrderMutation.isPending ? "Memproses..." : "Lanjut ke Pembayaran"}
      </button>
    </div>
  );
}
