import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useNavigate } from "react-router-dom";
import { Minus, Plus, ShoppingCart, Zap, Check, Store } from "lucide-react";
import { api } from "../services/api.js";
import { useCart } from "../hooks/useCart.jsx";
import { useAuth } from "../hooks/useAuth.jsx";
import Skeleton from "../components/Skeleton.jsx";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const productQuery = useQuery({
    queryKey: ["product", id],
    queryFn: () => api.get(`/products/${id}`),
  });

  if (productQuery.isLoading) {
    return (
      <div className="flex flex-col gap-3">
        <Skeleton className="aspect-video" />
        <Skeleton className="h-6 w-2/3" />
        <Skeleton className="h-20" />
      </div>
    );
  }
  if (productQuery.isError) return <p className="text-red-400">Produk tidak ditemukan.</p>;

  const p = productQuery.data;
  const outOfStock = p.stock_type === "LIMITED" && p.stock_available <= 0;

  function handleAddToCart() {
    if (!user) return navigate("/login");
    addItem(p, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  function handleBuyNow() {
    if (!user) return navigate("/login");
    addItem(p, qty);
    navigate("/checkout");
  }

  return (
    <div className="flex flex-col gap-4 pb-28">
      <div className="aspect-video rounded-2xl bg-slate-900 ring-1 ring-slate-800" />
      <div>
        <h1 className="text-lg font-bold leading-snug">{p.name}</h1>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-400">
          <Store size={14} />
          {p.game_name} • {p.seller_name}
        </p>
      </div>

      <p className="text-2xl font-bold text-brand">Rp{Number(p.price_amount).toLocaleString("id-ID")}</p>

      {p.description && <p className="whitespace-pre-line text-sm text-slate-300">{p.description}</p>}

      {p.stock_type === "LIMITED" && (
        <p className={`text-sm ${outOfStock ? "text-red-400" : "text-slate-400"}`}>
          {outOfStock ? "Stok habis" : `Sisa stok: ${p.stock_available}`}
        </p>
      )}

      {!outOfStock && (
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-400">Jumlah</span>
          <div className="flex items-center gap-3 rounded-full bg-slate-900 px-1 py-1 ring-1 ring-slate-800">
            <button
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="flex h-8 w-8 items-center justify-center rounded-full text-slate-300 hover:bg-slate-800"
            >
              <Minus size={16} />
            </button>
            <span className="w-5 text-center text-sm font-medium">{qty}</span>
            <button
              onClick={() => setQty((q) => q + 1)}
              className="flex h-8 w-8 items-center justify-center rounded-full text-slate-300 hover:bg-slate-800"
            >
              <Plus size={16} />
            </button>
          </div>
        </div>
      )}

      <div className="fixed bottom-16 left-0 right-0 border-t border-slate-800/80 bg-slate-950/95 p-3 backdrop-blur-lg">
        <div className="mx-auto flex max-w-lg gap-2">
          <button
            disabled={outOfStock}
            onClick={handleAddToCart}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-sm font-medium ring-1 ring-slate-800 disabled:opacity-50"
          >
            {added ? <Check size={18} className="text-emerald-400" /> : <ShoppingCart size={18} />}
            {added ? "Ditambahkan" : "Keranjang"}
          </button>
          <button
            disabled={outOfStock}
            onClick={handleBuyNow}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand py-3 text-sm font-medium text-white disabled:opacity-50"
          >
            <Zap size={18} />
            Beli Sekarang
          </button>
        </div>
      </div>
    </div>
  );
}
