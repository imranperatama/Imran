import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";

export default function GameDetail() {
  const { slug } = useParams();
  const gameQuery = useQuery({ queryKey: ["game", slug], queryFn: () => api.get(`/games/${slug}`) });
  const productsQuery = useQuery({
    queryKey: ["products", "byGame", slug],
    queryFn: () => api.get(`/products?gameSlug=${slug}`),
    enabled: !!slug,
  });

  if (gameQuery.isLoading) return <Skeleton className="h-40" />;
  if (gameQuery.isError) return <p className="text-red-400">Game tidak ditemukan.</p>;

  const game = gameQuery.data;

  return (
    <div>
      <div className="mb-4 rounded-xl bg-slate-900 p-4">
        <h1 className="text-lg font-bold">{game.name}</h1>
        <div className="mt-2 flex flex-wrap gap-2">
          {game.categories.map((c) => (
            <span key={c.id} className="rounded-full bg-slate-800 px-3 py-1 text-xs">
              {c.name}
            </span>
          ))}
        </div>
      </div>

      <h2 className="mb-3 font-semibold">Produk</h2>
      {productsQuery.isLoading ? (
        <Skeleton className="h-32" />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {productsQuery.data.items.map((p) => (
            <Link key={p.id} to={`/products/${p.id}`} className="rounded-xl bg-slate-900 p-3">
              <p className="line-clamp-1 text-sm font-medium">{p.name}</p>
              <p className="mt-1 text-sm font-semibold text-brand">
                Rp{Number(p.price_amount).toLocaleString("id-ID")}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
