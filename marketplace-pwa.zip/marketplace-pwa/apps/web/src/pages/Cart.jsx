import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, X, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart } from "../hooks/useCart.jsx";
import EmptyState from "../components/EmptyState.jsx";

export default function Cart() {
  const { items, updateQuantity, removeItem, total } = useCart();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <EmptyState
        icon={ShoppingBag}
        title="Keranjang kosong"
        description="Yuk cari produk favoritmu"
        action={
          <Link to="/games" className="mt-2 rounded-full bg-brand px-5 py-2 text-sm font-medium text-white">
            Jelajahi Produk
          </Link>
        }
      />
    );
  }

  return (
    <div className="flex flex-col gap-3 pb-28">
      <h1 className="text-lg font-semibold">Keranjang</h1>
      {items.map((item) => (
        <div key={item.productId} className="flex items-center gap-3 rounded-2xl bg-slate-900 p-3 ring-1 ring-slate-800">
          <div className="h-14 w-14 shrink-0 rounded-xl bg-slate-800" />
          <div className="min-w-0 flex-1">
            <p className="line-clamp-1 text-sm font-medium">{item.name}</p>
            <p className="text-sm text-brand">Rp{Number(item.priceAmount).toLocaleString("id-ID")}</p>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-slate-800/60 px-1 py-1">
            <button
              onClick={() => updateQuantity(item.productId, item.quantity - 1)}
              className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-slate-700"
            >
              <Minus size={14} />
            </button>
            <span className="w-5 text-center text-sm">{item.quantity}</span>
            <button
              onClick={() => updateQuantity(item.productId, item.quantity + 1)}
              className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-slate-700"
            >
              <Plus size={14} />
            </button>
          </div>
          <button onClick={() => removeItem(item.productId)} className="text-slate-500 hover:text-red-400">
            <X size={18} />
          </button>
        </div>
      ))}

      <div className="fixed bottom-16 left-0 right-0 border-t border-slate-800/80 bg-slate-950/95 p-4 backdrop-blur-lg">
        <div className="mx-auto flex max-w-lg items-center justify-between">
          <div>
            <p className="text-xs text-slate-400">Total</p>
            <p className="text-lg font-bold">Rp{total.toLocaleString("id-ID")}</p>
          </div>
          <button
            onClick={() => navigate("/checkout")}
            className="flex items-center gap-1.5 rounded-full bg-brand px-6 py-3 text-sm font-medium text-white"
          >
            Checkout
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
