import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Wallet, ShieldCheck, Loader2, CheckCircle2 } from "lucide-react";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";

const METHODS = [
  { id: "GOPAY", name: "GoPay", accent: "bg-[#00AA5B]" },
  { id: "OVO", name: "OVO", accent: "bg-[#4C3494]" },
  { id: "DANA", name: "DANA", accent: "bg-[#118EEA]" },
  { id: "SHOPEEPAY", name: "ShopeePay", accent: "bg-[#EE4D2D]" },
];

/**
 * Halaman "bayar" — nominal SELALU tampil apa adanya dari backend
 * (GET /api/payments/:id), tidak ada input manual sama sekali. User
 * cuma pilih e-wallet lalu konfirmasi, persis alur Snap/checkout
 * gateway asli — bedanya di sini masih SANDBOX (lihat badge di bawah).
 */
export default function Pay() {
  const { paymentId } = useParams();
  const navigate = useNavigate();
  const [method, setMethod] = useState("GOPAY");
  const [error, setError] = useState("");

  const paymentQuery = useQuery({
    queryKey: ["payment", paymentId],
    queryFn: () => api.get(`/payments/${paymentId}`),
  });

  const payMutation = useMutation({
    mutationFn: () => api.post(`/payments/${paymentId}/simulate`, { method }),
    onSuccess: (payment) => navigate(`/orders/${payment.order_id}`, { replace: true }),
    onError: (err) => setError(err.message),
  });

  if (paymentQuery.isLoading) {
    return (
      <div className="flex flex-col gap-3">
        <Skeleton className="h-28" />
        <Skeleton className="h-40" />
      </div>
    );
  }
  if (paymentQuery.isError) return <p className="text-red-400">Pembayaran tidak ditemukan.</p>;

  const payment = paymentQuery.data;
  const isProcessing = payMutation.isPending;
  const isDone = payMutation.isSuccess;

  return (
    <div className="mx-auto flex max-w-sm flex-col gap-5 pt-4">
      <div className="flex items-center justify-center gap-1.5 text-xs font-medium text-amber-400">
        <ShieldCheck size={14} />
        Mode Sandbox — simulasi pembayaran, tidak ada uang asli diproses
      </div>

      <div className="rounded-2xl bg-slate-900 p-5 text-center ring-1 ring-slate-800">
        <p className="text-sm text-slate-400">Total Pembayaran</p>
        <p className="mt-1 text-3xl font-bold text-white">
          Rp{Number(payment.amount).toLocaleString("id-ID")}
        </p>
        <p className="mt-1 text-xs text-slate-500">{payment.order_number}</p>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-slate-300">Pilih e-wallet</p>
        <div className="grid grid-cols-2 gap-2">
          {METHODS.map((m) => (
            <button
              key={m.id}
              disabled={isProcessing || isDone}
              onClick={() => setMethod(m.id)}
              className={`flex items-center gap-2 rounded-xl p-3 text-left ring-1 transition ${
                method === m.id ? "ring-2 ring-brand bg-slate-900" : "ring-slate-800 bg-slate-900/60"
              } disabled:opacity-50`}
            >
              <span className={`flex h-8 w-8 items-center justify-center rounded-lg text-white ${m.accent}`}>
                <Wallet size={16} />
              </span>
              <span className="text-sm font-medium">{m.name}</span>
            </button>
          ))}
        </div>
      </div>

      {error && <p className="text-center text-sm text-red-400">{error}</p>}

      <button
        disabled={isProcessing || isDone}
        onClick={() => payMutation.mutate()}
        className="flex items-center justify-center gap-2 rounded-xl bg-brand py-3.5 font-medium text-white disabled:opacity-60"
      >
        {isDone ? (
          <>
            <CheckCircle2 size={18} /> Berhasil, mengarahkan...
          </>
        ) : isProcessing ? (
          <>
            <Loader2 size={18} className="animate-spin" /> Memproses pembayaran...
          </>
        ) : (
          `Bayar dengan ${METHODS.find((m) => m.id === method)?.name}`
        )}
      </button>

      <p className="text-center text-xs text-slate-500">
        Dana akan otomatis ditahan di sistem rekber (escrow) begitu pembayaran dikonfirmasi.
      </p>
    </div>
  );
}
