import { useQuery } from "@tanstack/react-query";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";
import EmptyState from "../components/EmptyState.jsx";

const TYPE_LABEL = {
  DEPOSIT: "Deposit",
  ESCROW_HOLD: "Dana Ditahan",
  ESCROW_RELEASE: "Dana Diterima",
  REFUND: "Refund",
  WITHDRAWAL: "Penarikan",
  ADJUSTMENT: "Penyesuaian",
};

export default function Wallet() {
  const walletQuery = useQuery({ queryKey: ["wallet"], queryFn: () => api.get("/wallet") });
  const txQuery = useQuery({
    queryKey: ["wallet", "transactions"],
    queryFn: () => api.get("/wallet/transactions"),
  });

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl bg-gradient-to-br from-brand to-brand-dark p-6">
        <p className="text-sm text-white/80">Saldo Wallet</p>
        {walletQuery.isLoading ? (
          <Skeleton className="mt-2 h-8 w-32 bg-white/20" />
        ) : (
          <p className="mt-1 text-2xl font-bold text-white">
            Rp{Number(walletQuery.data.balance).toLocaleString("id-ID")}
          </p>
        )}
      </div>

      <h2 className="font-semibold">Riwayat Transaksi</h2>
      {txQuery.isLoading ? (
        <div className="flex flex-col gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-12" />
          ))}
        </div>
      ) : txQuery.data.length === 0 ? (
        <EmptyState title="Belum ada transaksi wallet" />
      ) : (
        <div className="flex flex-col gap-2">
          {txQuery.data.map((tx) => (
            <div key={tx.id} className="flex items-center justify-between rounded-xl bg-slate-900 p-3">
              <div>
                <p className="text-sm font-medium">{TYPE_LABEL[tx.type] || tx.type}</p>
                <p className="text-xs text-slate-500">{new Date(tx.created_at).toLocaleString("id-ID")}</p>
              </div>
              <span className={`text-sm font-semibold ${tx.amount >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {tx.amount >= 0 ? "+" : ""}
                Rp{Number(tx.amount).toLocaleString("id-ID")}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
