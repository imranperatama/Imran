import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.jsx";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: "", email: "", password: "", role: "buyer" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await register(form);
      navigate("/login");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto mt-10 max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Buat Akun</h1>
      <form onSubmit={onSubmit} className="flex flex-col gap-3">
        <input
          required
          placeholder="Nama lengkap"
          className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800 focus:ring-brand"
          value={form.fullName}
          onChange={(e) => setForm({ ...form, fullName: e.target.value })}
        />
        <input
          type="email"
          required
          placeholder="Email"
          className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800 focus:ring-brand"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          type="password"
          required
          minLength={8}
          placeholder="Password (min. 8 karakter)"
          className="rounded-lg bg-slate-900 px-4 py-3 outline-none ring-1 ring-slate-800 focus:ring-brand"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />

        <div className="flex gap-2">
          {["buyer", "seller"].map((role) => (
            <button
              type="button"
              key={role}
              onClick={() => setForm({ ...form, role })}
              className={`flex-1 rounded-lg py-2 text-sm capitalize ${
                form.role === role ? "bg-brand text-white" : "bg-slate-900 text-slate-300"
              }`}
            >
              {role === "buyer" ? "Pembeli" : "Penjual"}
            </button>
          ))}
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}
        <button
          disabled={loading}
          className="rounded-lg bg-brand py-3 font-medium text-white disabled:opacity-50"
        >
          {loading ? "Memproses..." : "Daftar"}
        </button>
      </form>
      <p className="mt-4 text-center text-sm text-slate-400">
        Sudah punya akun?{" "}
        <Link to="/login" className="text-brand">
          Masuk
        </Link>
      </p>
    </div>
  );
}
