import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { api } from "../services/api.js";
import Skeleton from "../components/Skeleton.jsx";
import EmptyState from "../components/EmptyState.jsx";

const STATUS_LABEL = {
  CREATED: "Dibuat",
  PAYMENT_PENDING: "Menunggu Pembayaran",
  PAYMENT_CONFIRMED: "Pembayaran Dikonfirmasi",
  ESCROW_HELD: "Dana Ditahan (Escrow)",
  PROCESSING: "Diproses",
  DELIVERED: "Dikirim",
  COMPLETED: "Selesai",
  REFUND: "Proses Refund",
  REFUNDED: "Direfund",
  CANCELLED: "Dibatalkan",
};

const STATUS_COLOR = {
  COMPLETED: "text-emerald-400",
  CANCELLED: "text-red-400",
  REFUNDED: "text-red-400",
};

export default function Orders() {
  const ordersQuery = useQuery({ queryKey: ["orders", "mine"], queryFn: () => api.get("/orders") });

  if (ordersQuery.isLoading) {
    return (
      <div className="flex flex-col gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16" />
        ))}
      </div>
    );
  }

  if (ordersQuery.data.length === 0) {
    return <EmptyState title="Belum ada pesanan" description="Riwayat transaksimu akan muncul di sini" />;
  }

  return (
    <div className="flex flex-col gap-3">
      <h1 className="text-lg font-semibold">Pesanan Saya</h1>
      {ordersQuery.data.map((o) => (
        <Link key={o.id} to={`/orders/${o.id}`} className="rounded-xl bg-slate-900 p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">{o.order_number}</span>
            <span className={`text-xs ${STATUS_COLOR[o.status] || "text-amber-400"}`}>
              {STATUS_LABEL[o.status] || o.status}
            </span>
          </div>
          <p className="mt-1 text-sm text-slate-400">
            Rp{Number(o.total_amount).toLocaleString("id-ID")}
          </p>
        </Link>
      ))}
    </div>
  );
}
