import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, setAccessToken, getAccessToken, BASE_URL } from "../services/api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Saat app pertama kali dimuat, coba tukar refresh cookie (httpOnly)
  // dengan access token baru secara diam-diam — supaya user tetap login
  // setelah refresh halaman, tanpa pernah menyimpan token di localStorage.
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${BASE_URL}/auth/refresh`, { method: "POST", credentials: "include" });
        if (res.ok) {
          const { data } = await res.json();
          setAccessToken(data.accessToken);
          setUser(data.user);
        }
      } catch {
        // belum login / cookie tidak ada — biarkan user null
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const login = useCallback(async (email, password) => {
    const data = await api.post("/auth/login", { email, password });
    setAccessToken(data.accessToken);
    setUser(data.user);
    return data.user;
  }, []);

  const register = useCallback(async (input) => {
    return api.post("/auth/register", input);
  }, []);

  const logout = useCallback(async () => {
    await api.post("/auth/logout", {});
    setAccessToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, isAuthed: !!getAccessToken() }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth harus dipakai di dalam <AuthProvider>");
  return ctx;
}
