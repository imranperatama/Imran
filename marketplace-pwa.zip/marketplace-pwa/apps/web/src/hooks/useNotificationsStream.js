import { useEffect, useState } from "react";
import { getAccessToken, BASE_URL } from "../services/api.js";

/**
 * Buka koneksi SSE ke /api/notifications/stream untuk notifikasi realtime
 * (badge, toast pesanan baru, dst). Token dikirim lewat query string karena
 * EventSource browser tidak bisa set header Authorization custom.
 */
export function useNotificationsStream(onNotification) {
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) return;

    const source = new EventSource(`${BASE_URL}/notifications/stream?token=${encodeURIComponent(token)}`);

    source.addEventListener("connected", () => setConnected(true));
    source.addEventListener("notification", (event) => {
      const data = JSON.parse(event.data);
      onNotification?.(data);
    });
    source.onerror = () => setConnected(false);

    return () => source.close();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [getAccessToken()]);

  return { connected };
}
