/**
 * Wrapper fetch tunggal untuk semua panggilan API.
 *
 * - Access token disimpan di MEMORI (variabel modul), BUKAN localStorage,
 *   supaya tidak bisa dicuri lewat XSS yang berhasil inject script.
 * - Refresh token ada di httpOnly cookie (diatur backend), tidak pernah
 *   disentuh JavaScript di sini sama sekali.
 * - Saat access token expired (401), otomatis coba refresh sekali,
 *   lalu ulangi request asli.
 */

let accessToken = null;

export function setAccessToken(token) {
  accessToken = token;
}

export function getAccessToken() {
  return accessToken;
}

/**
 * BASE_URL production diambil dari VITE_API_BASE_URL (di-bake saat build,
 * lihat vite.config.js & .env.example). Kalau kosong (dev lokal), fallback
 * ke "/api" yang ditangani proxy Vite ke localhost:4000 — proxy itu
 * HANYA berlaku saat `npm run dev`, tidak ikut ke hasil build production,
 * jadi tanpa VITE_API_BASE_URL, build production akan salah target
 * (request jatuh ke domain Netlify sendiri, bukan backend).
 */
export const BASE_URL = import.meta.env.VITE_API_BASE_URL || "/api";

async function rawFetch(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
    credentials: "include", // wajib supaya cookie refresh_token ikut terkirim
  });
  return res;
}

async function tryRefresh() {
  const res = await fetch(`${BASE_URL}/auth/refresh`, { method: "POST", credentials: "include" });
  if (!res.ok) return false;
  const { data } = await res.json();
  setAccessToken(data.accessToken);
  return true;
}

export async function apiFetch(path, options = {}) {
  let res = await rawFetch(path, options);

  if (res.status === 401 && accessToken) {
    const refreshed = await tryRefresh();
    if (refreshed) {
      res = await rawFetch(path, options);
    }
  }

  const isJson = res.headers.get("content-type")?.includes("application/json");
  const body = isJson ? await res.json() : null;

  if (!res.ok) {
    const message = body?.error?.message || `Request gagal (${res.status})`;
    throw new Error(message);
  }
  return body?.data;
}

export const api = {
  get: (path) => apiFetch(path),
  post: (path, body, extraHeaders) =>
    apiFetch(path, { method: "POST", body: JSON.stringify(body), headers: extraHeaders }),
  patch: (path, body) => apiFetch(path, { method: "PATCH", body: JSON.stringify(body) }),
  delete: (path) => apiFetch(path, { method: "DELETE" }),
};

/** Generate idempotency key acak untuk operasi create (order, payment, dst). */
export function newIdempotencyKey() {
  return crypto.randomUUID();
}
