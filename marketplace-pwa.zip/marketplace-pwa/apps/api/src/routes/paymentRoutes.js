import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { requireIdempotencyKey } from "../middleware/idempotency.js";
import { devOnly } from "../middleware/devOnly.js";
import { postInitiatePayment, getPayment, postSimulatePayment } from "../controllers/paymentController.js";

// Route webhook SENGAJA tidak ada di sini — dipasang langsung di app.js
// dengan express.raw() supaya signature bisa diverifikasi dari body mentah.
const router = Router();

router.post("/", requireAuth, requireIdempotencyKey, postInitiatePayment);
router.get("/:id", requireAuth, getPayment);
router.post("/:id/simulate", requireAuth, devOnly, postSimulatePayment);

export default router;
