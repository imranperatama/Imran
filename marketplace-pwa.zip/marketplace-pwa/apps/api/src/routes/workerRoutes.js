import { Router } from "express";
import { requireWorkerAuth } from "../middleware/workerAuth.js";
import { getNextJob, postJobResult } from "../controllers/workerController.js";

const router = Router();

router.use(requireWorkerAuth);
router.get("/jobs/next", getNextJob);
router.post("/jobs/:id/result", postJobResult);

export default router;
