import { Router } from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { requireIdempotencyKey } from "../middleware/idempotency.js";
import { postOrder, getMyOrders, getOrder } from "../controllers/orderController.js";

const router = Router();

router.use(requireAuth);

// requireRole("buyer") TIDAK dipasang di sini secara sengaja: seller pun
// boleh membeli dari toko lain. Yang membedakan hanyalah wallet & produk
// mana yang mereka sentuh, bukan role akunnya.
router.post("/", requireRole("buyer", "seller", "admin"), requireIdempotencyKey, postOrder);
router.get("/", getMyOrders);
router.get("/:id", getOrder);

export default router;
