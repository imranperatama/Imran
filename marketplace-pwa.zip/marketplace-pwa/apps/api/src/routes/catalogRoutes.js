import { Router } from "express";
import { getGames, getGameDetail, getProducts, getProductDetail } from "../controllers/catalogController.js";

const router = Router();

// Semua route di sini publik (tidak butuh login) — sesuai spesifikasi
// halaman publik: "/games", "/games/:slug", "/products/:id".
router.get("/games", getGames);
router.get("/games/:slug", getGameDetail);
router.get("/products", getProducts);
router.get("/products/:id", getProductDetail);

export default router;
