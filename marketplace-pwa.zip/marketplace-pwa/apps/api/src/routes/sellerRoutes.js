import { Router } from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { postProduct, patchProduct, removeProduct, getMyProducts } from "../controllers/sellerProductController.js";
import { getMySellerOrders } from "../controllers/orderController.js";
import { getSellerWallet, getSellerWalletTransactions } from "../controllers/walletController.js";

const router = Router();

// Semua route di bawah ini wajib login DAN berperan seller (RBAC server-side).
router.use(requireAuth, requireRole("seller"));

router.get("/products", getMyProducts);
router.post("/products", postProduct);
router.patch("/products/:id", patchProduct);
router.delete("/products/:id", removeProduct);

router.get("/orders", getMySellerOrders);

router.get("/wallet", getSellerWallet);
router.get("/wallet/transactions", getSellerWalletTransactions);

export default router;
