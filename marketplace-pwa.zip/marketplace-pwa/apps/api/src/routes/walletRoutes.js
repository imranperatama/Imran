import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { getMyWallet, getMyWalletTransactions } from "../controllers/walletController.js";

const router = Router();

router.use(requireAuth);
router.get("/", getMyWallet);
router.get("/transactions", getMyWalletTransactions);

export default router;
