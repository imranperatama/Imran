import { Router } from "express";
import { requireAuth, requireAuthSSE } from "../middleware/auth.js";
import {
  getNotifications,
  patchNotificationRead,
  streamNotifications,
} from "../controllers/notificationController.js";

const router = Router();

// Stream pakai requireAuthSSE (token lewat query) karena keterbatasan EventSource.
router.get("/stream", requireAuthSSE, streamNotifications);

router.use(requireAuth);
router.get("/", getNotifications);
router.patch("/:id/read", patchNotificationRead);

export default router;
