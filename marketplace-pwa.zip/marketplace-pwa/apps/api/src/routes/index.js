import { Router } from "express";
import authRoutes from "./authRoutes.js";
import catalogRoutes from "./catalogRoutes.js";
import sellerRoutes from "./sellerRoutes.js";
import orderRoutes from "./orderRoutes.js";
import walletRoutes from "./walletRoutes.js";
import paymentRoutes from "./paymentRoutes.js";
import workerRoutes from "./workerRoutes.js";
import notificationRoutes from "./notificationRoutes.js";

const router = Router();

router.get("/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

router.use("/auth", authRoutes);
router.use("/", catalogRoutes); // /games, /categories, /products (publik)
router.use("/seller", sellerRoutes);
router.use("/orders", orderRoutes);
router.use("/wallet", walletRoutes);
router.use("/payments", paymentRoutes);
router.use("/worker", workerRoutes);
router.use("/notifications", notificationRoutes);

export default router;
