/**
 * Hub in-memory sederhana untuk Server-Sent Events. Menyimpan koneksi
 * response aktif per userId, supaya notifikasi baru bisa langsung
 * di-push tanpa polling dari frontend.
 *
 * CATATAN SKALA: implementasi in-memory ini cukup untuk 1 instance
 * backend. Kalau nanti backend di-scale ke banyak instance/pod,
 * gantilah dengan pub/sub eksternal (mis. Redis pub/sub) supaya
 * notifikasi tetap sampai ke user walau koneksi SSE-nya dipegang
 * instance server yang berbeda dari yang memicu notifikasi.
 */
class SseHub {
  constructor() {
    /** @type {Map<string, Set<import('express').Response>>} */
    this.connections = new Map();
  }

  addConnection(userId, res) {
    if (!this.connections.has(userId)) {
      this.connections.set(userId, new Set());
    }
    this.connections.get(userId).add(res);
  }

  removeConnection(userId, res) {
    this.connections.get(userId)?.delete(res);
    if (this.connections.get(userId)?.size === 0) {
      this.connections.delete(userId);
    }
  }

  sendToUser(userId, event, data) {
    const sockets = this.connections.get(userId);
    if (!sockets) return;
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of sockets) {
      res.write(payload);
    }
  }
}

export const sseHub = new SseHub();
