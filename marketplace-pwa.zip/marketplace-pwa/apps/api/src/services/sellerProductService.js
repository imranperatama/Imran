import { query, withTransaction } from "../config/db.js";
import { toSlug } from "../utils/slug.js";
import { ApiError } from "../utils/ApiError.js";

async function getSellerProfileByUserId(userId) {
  const { rows } = await query("SELECT id FROM seller_profiles WHERE user_id = $1", [userId]);
  if (!rows[0]) throw ApiError.forbidden("Akun ini belum punya toko seller");
  return rows[0];
}

export async function createProduct(userId, input) {
  const seller = await getSellerProfileByUserId(userId);
  const baseSlug = toSlug(input.name);

  return withTransaction(async (client) => {
    // Pastikan slug unik per-seller: kalau bentrok, tambahkan suffix pendek.
    let slug = baseSlug;
    const { rows: clash } = await client.query(
      "SELECT 1 FROM products WHERE seller_id = $1 AND slug = $2",
      [seller.id, slug]
    );
    if (clash.length > 0) {
      slug = `${baseSlug}-${Date.now().toString(36)}`;
    }

    const { rows } = await client.query(
      `INSERT INTO products
         (seller_id, game_id, category_id, name, slug, description,
          product_type, price_amount, thumbnail_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING id, name, slug, price_amount, product_type, is_active`,
      [
        seller.id,
        input.gameId,
        input.categoryId,
        input.name,
        slug,
        input.description ?? null,
        input.productType,
        input.priceAmount,
        input.thumbnailUrl ?? null,
      ]
    );
    const product = rows[0];

    await client.query(
      `INSERT INTO product_stock (product_id, stock_type, quantity_available)
       VALUES ($1, $2, $3)`,
      [product.id, input.initialStock > 0 ? "LIMITED" : "UNLIMITED", input.initialStock]
    );

    return product;
  });
}

async function assertOwnership(client, productId, sellerId) {
  const { rows } = await client.query("SELECT id FROM products WHERE id = $1 AND seller_id = $2", [
    productId,
    sellerId,
  ]);
  if (!rows[0]) throw ApiError.notFound("Produk tidak ditemukan atau bukan milik toko ini");
}

export async function updateProduct(userId, productId, input) {
  const seller = await getSellerProfileByUserId(userId);

  return withTransaction(async (client) => {
    await assertOwnership(client, productId, seller.id);

    const fields = [];
    const params = [];
    const map = {
      gameId: "game_id",
      categoryId: "category_id",
      name: "name",
      description: "description",
      productType: "product_type",
      priceAmount: "price_amount",
      thumbnailUrl: "thumbnail_url",
    };

    for (const [key, column] of Object.entries(map)) {
      if (input[key] !== undefined) {
        params.push(input[key]);
        fields.push(`${column} = $${params.length}`);
      }
    }
    if (fields.length === 0) throw ApiError.badRequest("Tidak ada field untuk diupdate");

    params.push(productId);
    const { rows } = await client.query(
      `UPDATE products SET ${fields.join(", ")} WHERE id = $${params.length}
       RETURNING id, name, slug, price_amount, product_type, is_active`,
      params
    );
    return rows[0];
  });
}

export async function deleteProduct(userId, productId) {
  const seller = await getSellerProfileByUserId(userId);
  return withTransaction(async (client) => {
    await assertOwnership(client, productId, seller.id);
    // Soft delete: tetap simpan histori untuk order_items yang sudah ada.
    await client.query("UPDATE products SET is_active = false WHERE id = $1", [productId]);
  });
}

export async function listMyProducts(userId) {
  const seller = await getSellerProfileByUserId(userId);
  const { rows } = await query(
    `SELECT id, name, slug, price_amount, product_type, is_active, created_at
     FROM products WHERE seller_id = $1 ORDER BY created_at DESC`,
    [seller.id]
  );
  return rows;
}
