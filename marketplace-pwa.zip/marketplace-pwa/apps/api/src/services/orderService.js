import { withTransaction, query } from "../config/db.js";
import { applyWalletTransaction } from "./walletService.js";
import { ApiError } from "../utils/ApiError.js";
import { createNotification } from "./notificationService.js";

function generateOrderNumber() {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `ORD-${date}-${rand}`;
}

/**
 * Membuat order dari daftar {productId, quantity}. SEMUA harga, nama
 * penjual, dan validasi stok diambil ulang dari database di dalam
 * transaction ini — payload dari client tidak pernah dipercaya untuk
 * angka apapun (sesuai catatan security di ARCHITECTURE.md §4).
 *
 * idempotencyKey mencegah double-submit (mis. user klik "Beli" 2x)
 * membuat 2 order terpisah.
 */
export async function createOrder(buyerId, { items }, idempotencyKey) {
  return withTransaction(async (client) => {
    const existing = await client.query("SELECT * FROM orders WHERE idempotency_key = $1", [
      idempotencyKey,
    ]);
    if (existing.rows[0]) {
      return getOrderDetail(existing.rows[0].id, client);
    }

    let totalAmount = 0;
    const resolvedItems = [];

    for (const item of items) {
      // FOR UPDATE di produk+stok mencegah dua buyer sama-sama "berhasil"
      // membeli unit stok terakhir secara bersamaan (race condition).
      const { rows } = await client.query(
        `SELECT p.id, p.seller_id, p.price_amount, p.is_active,
                ps.id AS stock_id, ps.stock_type, ps.quantity_available
         FROM products p
         LEFT JOIN product_stock ps ON ps.product_id = p.id
         WHERE p.id = $1
         FOR UPDATE OF p`,
        [item.productId]
      );
      const product = rows[0];
      if (!product || !product.is_active) {
        throw ApiError.badRequest(`Produk ${item.productId} tidak tersedia`);
      }
      if (product.stock_type === "LIMITED" && product.quantity_available < item.quantity) {
        throw ApiError.badRequest(`Stok produk ${item.productId} tidak mencukupi`);
      }

      const subtotal = product.price_amount * item.quantity;
      totalAmount += subtotal;
      resolvedItems.push({ ...item, product, subtotal });
    }

    const { rows: orderRows } = await client.query(
      `INSERT INTO orders (order_number, buyer_id, status, total_amount, idempotency_key)
       VALUES ($1,$2,'CREATED',$3,$4)
       RETURNING id, order_number, status, total_amount, created_at`,
      [generateOrderNumber(), buyerId, totalAmount, idempotencyKey]
    );
    const order = orderRows[0];

    for (const item of resolvedItems) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, seller_id, quantity, unit_price, subtotal)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [order.id, item.product.id, item.product.seller_id, item.quantity, item.product.price_amount, item.subtotal]
      );

      if (item.product.stock_type === "LIMITED") {
        await client.query(
          `UPDATE product_stock SET quantity_available = quantity_available - $1,
                                     quantity_reserved = quantity_reserved + $1
           WHERE id = $2`,
          [item.quantity, item.product.stock_id]
        );
      }
    }

    await writeAudit(client, "system", buyerId, "order", order.id, "ORDER_CREATED", null, order);

    return getOrderDetail(order.id, client);
  }).then(async (orderDetail) => {
    // Notifikasi "ada pesanan baru" ke tiap seller yang terlibat (spec §pesan
    // notifikasi penjual). Dilakukan SETELAH transaction commit supaya tidak
    // menahan lock DB hanya untuk mengirim notifikasi.
    const { rows: sellers } = await query(
      `SELECT DISTINCT sp.user_id FROM order_items oi
       JOIN seller_profiles sp ON sp.id = oi.seller_id WHERE oi.order_id = $1`,
      [orderDetail.id]
    );
    for (const seller of sellers) {
      await createNotification({
        userId: seller.user_id,
        type: "NEW_ORDER",
        title: "Pesanan baru masuk",
        body: `Order ${orderDetail.order_number} menunggu diproses`,
        metadata: { orderId: orderDetail.id },
      });
    }
    return orderDetail;
  });
}

/**
 * Dipanggil SETELAH payment dikonfirmasi (dari payment webhook, Tahap 6).
 * Memindahkan dana dari "belum ditahan" menjadi ESCROW_HELD dan mencatat
 * baris escrow_transactions. Untuk produk AUTOMATED, langsung membuat bot_jobs.
 */
export async function moveOrderToEscrow(orderId, idempotencyKey) {
  return withTransaction(async (client) => {
    const { rows } = await client.query("SELECT * FROM orders WHERE id = $1 FOR UPDATE", [orderId]);
    const order = rows[0];
    if (!order) throw ApiError.notFound("Order tidak ditemukan");

    if (order.status !== "PAYMENT_CONFIRMED") {
      // Idempotent: kalau sudah lewat tahap ini, jangan proses ulang / jangan error keras.
      if (["ESCROW_HELD", "PROCESSING", "DELIVERED", "COMPLETED"].includes(order.status)) {
        return order;
      }
      throw ApiError.conflict(`Order berstatus ${order.status}, tidak bisa masuk escrow`);
    }

    await client.query(
      `INSERT INTO escrow_transactions (order_id, status, amount, held_at)
       VALUES ($1,'HELD',$2, now())`,
      [orderId, order.total_amount]
    );

    const { rows: updated } = await client.query(
      `UPDATE orders SET status = 'ESCROW_HELD' WHERE id = $1 RETURNING *`,
      [orderId]
    );

    await writeAudit(client, "system", null, "order", orderId, "ESCROW_HELD", order, updated[0]);

    // Untuk item produk otomatis, buat bot_jobs supaya worker Python bisa mengambilnya.
    const { rows: items } = await client.query(
      `SELECT oi.id, p.product_type FROM order_items oi
       JOIN products p ON p.id = oi.product_id WHERE oi.order_id = $1`,
      [orderId]
    );
    const automatedItems = items.filter((i) => i.product_type === "AUTOMATED");
    for (const item of automatedItems) {
      await client.query(
        `INSERT INTO bot_jobs (order_item_id, job_type, status, payload)
         VALUES ($1, 'DIGITAL_TOPUP', 'PENDING', $2)`,
        [item.id, JSON.stringify({ orderId, orderItemId: item.id })]
      );
    }

    if (automatedItems.length > 0) {
      await client.query(`UPDATE orders SET status = 'PROCESSING' WHERE id = $1`, [orderId]);
    }

    return updated[0];
  });
}

/**
 * Worker melaporkan hasil job (Tahap 7). Kalau SUKSES: release escrow ke
 * seller + tandai order DELIVERED/COMPLETED. Kalau GAGAL & sudah habis
 * percobaan: masukkan ke MANUAL_REVIEW (tidak auto-refund tanpa human review).
 */
export async function applyBotJobResult(jobId, { status, result }, workerIdempotencyKey) {
  return withTransaction(async (client) => {
    const { rows: jobRows } = await client.query("SELECT * FROM bot_jobs WHERE id = $1 FOR UPDATE", [
      jobId,
    ]);
    const job = jobRows[0];
    if (!job) throw ApiError.notFound("Job tidak ditemukan");
    if (["SUCCESS", "MANUAL_REVIEW"].includes(job.status)) {
      return { job, buyerId: null, orderId: null, notifySuccess: false }; // sudah final, abaikan laporan duplikat
    }

    const { rows: itemRows } = await client.query(
      `SELECT oi.*, o.id AS order_id, o.buyer_id, o.status AS order_status
       FROM order_items oi JOIN orders o ON o.id = oi.order_id
       WHERE oi.id = $1 FOR UPDATE OF o`,
      [job.order_item_id]
    );
    const item = itemRows[0];

    if (status === "SUCCESS") {
      await client.query(
        `UPDATE bot_jobs SET status = 'SUCCESS', result = $1 WHERE id = $2`,
        [JSON.stringify(result ?? {}), jobId]
      );
      await client.query(`UPDATE order_items SET delivery_reference = $1 WHERE id = $2`, [
        result?.deliveryReference ?? null,
        item.id,
      ]);

      // Release dana escrow ke wallet seller.
      const { rows: escrowRows } = await client.query(
        `SELECT * FROM escrow_transactions WHERE order_id = $1 FOR UPDATE`,
        [item.order_id]
      );
      const escrow = escrowRows[0];
      if (escrow && escrow.status === "HELD") {
        const { rows: sellerRows } = await client.query(
          "SELECT user_id FROM seller_profiles WHERE id = $1",
          [item.seller_id]
        );
        await applyWalletTransaction(client, {
          userId: sellerRows[0].user_id,
          type: "ESCROW_RELEASE",
          amount: item.subtotal,
          referenceType: "order",
          referenceId: item.order_id,
          idempotencyKey: `${item.order_id}:ESCROW_RELEASE:${item.id}`,
        });
        await client.query(`UPDATE escrow_transactions SET status = 'RELEASED', released_at = now() WHERE id = $1`, [
          escrow.id,
        ]);
      }

      await client.query(`UPDATE orders SET status = 'COMPLETED' WHERE id = $1`, [item.order_id]);
      await writeAudit(client, "worker", null, "order", item.order_id, "ORDER_COMPLETED_AUTO", null, result);
    } else {
      const attempts = job.attempts + 1;
      const nextStatus = attempts < job.max_attempts ? "RETRY" : "MANUAL_REVIEW";
      await client.query(`UPDATE bot_jobs SET status = $1, attempts = $2, result = $3 WHERE id = $4`, [
        nextStatus,
        attempts,
        JSON.stringify(result ?? {}),
        jobId,
      ]);
      if (nextStatus === "MANUAL_REVIEW") {
        await writeAudit(client, "worker", null, "bot_job", jobId, "MANUAL_REVIEW_REQUIRED", null, result);
      }
    }

    const { rows: refreshed } = await client.query("SELECT * FROM bot_jobs WHERE id = $1", [jobId]);
    return { job: refreshed[0], buyerId: item.buyer_id, orderId: item.order_id, notifySuccess: status === "SUCCESS" };
  }).then(async ({ job, buyerId, orderId, notifySuccess }) => {
    if (notifySuccess) {
      await createNotification({
        userId: buyerId,
        type: "ORDER_COMPLETED",
        title: "Pesanan selesai",
        body: "Produk digital kamu sudah berhasil diproses",
        metadata: { orderId },
      });
    }
    return job;
  });
}

export async function getOrderDetail(orderId, clientOverride) {
  const runner = clientOverride ?? { query };
  const { rows: orderRows } = await runner.query("SELECT * FROM orders WHERE id = $1", [orderId]);
  const order = orderRows[0];
  if (!order) throw ApiError.notFound("Order tidak ditemukan");

  const { rows: items } = await runner.query(
    `SELECT oi.id, oi.product_id, oi.quantity, oi.unit_price, oi.subtotal, oi.delivery_reference,
            p.name AS product_name
     FROM order_items oi JOIN products p ON p.id = oi.product_id
     WHERE oi.order_id = $1`,
    [orderId]
  );

  return { ...order, items };
}

export async function listOrdersByBuyer(buyerId) {
  const { rows } = await query(
    `SELECT id, order_number, status, total_amount, created_at
     FROM orders WHERE buyer_id = $1 ORDER BY created_at DESC`,
    [buyerId]
  );
  return rows;
}

export async function listOrdersBySeller(userId) {
  const { rows } = await query(
    `SELECT DISTINCT o.id, o.order_number, o.status, o.created_at, oi.subtotal
     FROM orders o
     JOIN order_items oi ON oi.order_id = o.id
     JOIN seller_profiles sp ON sp.id = oi.seller_id
     WHERE sp.user_id = $1
     ORDER BY o.created_at DESC`,
    [userId]
  );
  return rows;
}

async function writeAudit(client, actorType, actorId, entityType, entityId, action, before, after) {
  await client.query(
    `INSERT INTO audit_logs (actor_type, actor_id, entity_type, entity_id, action, before_state, after_state)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [actorType, actorId, entityType, entityId, action, before ? JSON.stringify(before) : null, after ? JSON.stringify(after) : null]
  );
}
