import { withTransaction, query } from "../config/db.js";

/**
 * Worker memanggil ini untuk "mengambil" satu job PENDING dan menguncinya
 * (locked_by + locked_at) supaya worker lain tidak mengambil job yang sama.
 * SELECT ... FOR UPDATE SKIP LOCKED = pola job-queue standar Postgres:
 * beberapa worker instance bisa polling bersamaan tanpa rebutan job.
 */
export async function claimNextJob(workerId) {
  return withTransaction(async (client) => {
    const { rows } = await client.query(
      `SELECT id, order_item_id, job_type, payload FROM bot_jobs
       WHERE status = 'PENDING'
       ORDER BY created_at ASC
       LIMIT 1
       FOR UPDATE SKIP LOCKED`
    );
    const job = rows[0];
    if (!job) return null;

    await client.query(
      `UPDATE bot_jobs SET status = 'RUNNING', locked_by = $1, locked_at = now() WHERE id = $2`,
      [workerId, job.id]
    );
    return job;
  });
}

/**
 * Job yang macet lebih dari N menit di status RUNNING (worker crash tanpa
 * lapor hasil) dikembalikan ke PENDING supaya bisa diambil worker lain.
 * Idealnya dipanggil dari cron/scheduled job, bukan tiap request.
 */
export async function reclaimStaleJobs(staleMinutes = 10) {
  const { rowCount } = await query(
    `UPDATE bot_jobs SET status = 'PENDING', locked_by = NULL, locked_at = NULL
     WHERE status = 'RUNNING' AND locked_at < now() - ($1 || ' minutes')::interval`,
    [staleMinutes]
  );
  return rowCount;
}
