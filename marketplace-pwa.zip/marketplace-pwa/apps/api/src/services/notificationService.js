import { query } from "../config/db.js";
import { sseHub } from "../realtime/sseHub.js";

export async function createNotification({ userId, type, title, body, metadata }) {
  const { rows } = await query(
    `INSERT INTO notifications (user_id, type, title, body, metadata)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [userId, type, title, body ?? null, JSON.stringify(metadata ?? {})]
  );
  const notification = rows[0];

  // Push realtime ke koneksi SSE user itu kalau sedang online.
  sseHub.sendToUser(userId, "notification", notification);

  return notification;
}

export async function listNotifications(userId, { page = 1, pageSize = 20 } = {}) {
  const offset = (page - 1) * pageSize;
  const { rows } = await query(
    `SELECT id, type, title, body, is_read, created_at
     FROM notifications WHERE user_id = $1
     ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [userId, pageSize, offset]
  );
  return rows;
}

export async function markNotificationRead(userId, notificationId) {
  await query(`UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2`, [
    notificationId,
    userId,
  ]);
}
