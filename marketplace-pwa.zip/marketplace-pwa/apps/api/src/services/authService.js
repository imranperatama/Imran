import crypto from "node:crypto";
import { query, withTransaction } from "../config/db.js";
import { hashPassword, verifyPassword } from "../utils/password.js";
import { signAccessToken, signRefreshToken } from "../utils/jwt.js";
import { ApiError } from "../utils/ApiError.js";

function toSlug(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export async function registerUser({ email, password, fullName, phone, role }) {
  const existing = await query("SELECT id FROM users WHERE email = $1", [email]);
  if (existing.rowCount > 0) {
    throw ApiError.conflict("Email sudah terdaftar");
  }

  const passwordHash = await hashPassword(password);

  const user = await withTransaction(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO users (email, password_hash, full_name, phone, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, email, full_name, role, created_at`,
      [email, passwordHash, fullName, phone ?? null, role]
    );
    const newUser = rows[0];

    // Setiap user (buyer maupun seller) dapat wallet sejak awal.
    await client.query(`INSERT INTO wallets (user_id, balance) VALUES ($1, 0)`, [newUser.id]);

    // Kalau daftar sebagai seller, langsung buatkan seller_profiles dasar.
    if (role === "seller") {
      const baseSlug = toSlug(fullName) || `toko-${newUser.id.slice(0, 8)}`;
      const storeSlug = `${baseSlug}-${newUser.id.slice(0, 6)}`;
      await client.query(
        `INSERT INTO seller_profiles (user_id, store_name, store_slug)
         VALUES ($1, $2, $3)`,
        [newUser.id, fullName, storeSlug]
      );
    }

    return newUser;
  });

  return user;
}

export async function authenticateUser({ email, password }) {
  const { rows } = await query(
    "SELECT id, email, password_hash, role, is_active FROM users WHERE email = $1",
    [email]
  );
  const user = rows[0];

  // Pesan error SENGAJA sama untuk "email tidak ada" maupun "password salah"
  // supaya tidak bisa dipakai untuk enumerasi email terdaftar.
  if (!user) {
    throw ApiError.unauthorized("Email atau password salah");
  }
  if (!user.is_active) {
    throw ApiError.forbidden("Akun dinonaktifkan, hubungi admin");
  }

  const valid = await verifyPassword(user.password_hash, password);
  if (!valid) {
    throw ApiError.unauthorized("Email atau password salah");
  }

  return issueTokenPair(user);
}

export function issueTokenPair(user) {
  const jti = crypto.randomUUID();
  const accessToken = signAccessToken({ sub: user.id, role: user.role });
  const refreshToken = signRefreshToken({ sub: user.id, role: user.role, jti });
  return {
    accessToken,
    refreshToken,
    user: { id: user.id, email: user.email, role: user.role },
  };
}

export async function getUserById(id) {
  const { rows } = await query(
    "SELECT id, email, full_name, phone, role, is_active, created_at FROM users WHERE id = $1",
    [id]
  );
  return rows[0] ?? null;
}
