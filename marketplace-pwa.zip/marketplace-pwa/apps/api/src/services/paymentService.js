import { withTransaction, query } from "../config/db.js";
import { createPaymentIntent } from "../providers/mockPaymentProvider.js";
import { moveOrderToEscrow } from "./orderService.js";
import { ApiError } from "../utils/ApiError.js";

/**
 * Dipanggil buyer setelah order dibuat, untuk mulai proses bayar.
 * Membuat baris `payments` berstatus PENDING + reference dari provider.
 */
export async function initiatePayment(orderId, idempotencyKey) {
  return withTransaction(async (client) => {
    const existing = await client.query("SELECT * FROM payments WHERE idempotency_key = $1", [
      idempotencyKey,
    ]);
    if (existing.rows[0]) return existing.rows[0];

    const { rows: orderRows } = await client.query(
      "SELECT id, status, total_amount FROM orders WHERE id = $1 FOR UPDATE",
      [orderId]
    );
    const order = orderRows[0];
    if (!order) throw ApiError.notFound("Order tidak ditemukan");
    if (order.status !== "CREATED") {
      throw ApiError.conflict(`Order berstatus ${order.status}, tidak bisa mulai pembayaran baru`);
    }

    const { providerReference } = createPaymentIntent({ orderId, amount: order.total_amount });

    const { rows } = await client.query(
      `INSERT INTO payments (order_id, provider, provider_reference, status, amount, idempotency_key)
       VALUES ($1,'mock',$2,'PENDING',$3,$4)
       RETURNING *`,
      [orderId, providerReference, order.total_amount, idempotencyKey]
    );

    await client.query("UPDATE orders SET status = 'PAYMENT_PENDING' WHERE id = $1", [orderId]);

    return rows[0];
  });
}

/**
 * Dipanggil dari webhook SETELAH signature terverifikasi di controller.
 * idempotencyKey di sini dibentuk dari providerReference (bukan dari
 * client) supaya webhook yang di-retry provider tidak pernah dobel proses.
 */
export async function confirmPaymentFromWebhook({ providerReference, status, rawPayload }) {
  return withTransaction(async (client) => {
    const { rows: paymentRows } = await client.query(
      "SELECT * FROM payments WHERE provider_reference = $1 FOR UPDATE",
      [providerReference]
    );
    const payment = paymentRows[0];
    if (!payment) throw ApiError.notFound("Payment reference tidak dikenal");

    // Idempotent: kalau sudah CONFIRMED sebelumnya, jangan proses ulang efeknya.
    if (payment.status === "CONFIRMED") {
      return payment;
    }
    if (payment.status !== "PENDING") {
      throw ApiError.conflict(`Payment berstatus ${payment.status}, webhook diabaikan`);
    }

    const newStatus = status === "SUCCESS" ? "CONFIRMED" : "FAILED";
    const { rows: updated } = await client.query(
      `UPDATE payments SET status = $1, raw_payload = $2 WHERE id = $3 RETURNING *`,
      [newStatus, JSON.stringify(rawPayload ?? {}), payment.id]
    );

    if (newStatus === "CONFIRMED") {
      await client.query("UPDATE orders SET status = 'PAYMENT_CONFIRMED' WHERE id = $1", [
        payment.order_id,
      ]);
    } else {
      await client.query("UPDATE orders SET status = 'CANCELLED' WHERE id = $1", [payment.order_id]);
    }

    return updated[0];
  }).then(async (payment) => {
    // Escrow hold dilakukan di transaction TERPISAH setelah payment
    // ter-commit, supaya kalau langkah escrow gagal, status PAYMENT_CONFIRMED
    // tetap tersimpan dan bisa di-retry/diproses manual — bukan ikut rollback.
    if (payment.status === "CONFIRMED") {
      await moveOrderToEscrow(payment.order_id, `${payment.order_id}:ESCROW_HOLD`);
    }
    return payment;
  });
}

/**
 * Ambil detail payment untuk ditampilkan di halaman "bayar" (mock e-wallet).
 * Nominal SELALU dari data ini (server), TIDAK PERNAH dari input manual
 * user — sesuai permintaan: user tidak perlu ketik nominal sendiri.
 */
export async function getPaymentForCheckout(userId, paymentId) {
  const { rows } = await query(
    `SELECT p.id, p.amount, p.status, p.provider_reference, p.created_at,
            o.id AS order_id, o.order_number, o.buyer_id
     FROM payments p JOIN orders o ON o.id = p.order_id
     WHERE p.id = $1`,
    [paymentId]
  );
  const payment = rows[0];
  if (!payment) throw ApiError.notFound("Pembayaran tidak ditemukan");
  if (payment.buyer_id !== userId) throw ApiError.forbidden("Bukan pembayaran milikmu");
  return payment;
}

/**
 * DEV/SANDBOX ONLY (diblokir middleware `devOnly` di route-nya).
 * Mensimulasikan provider e-wallet (GoPay/OVO/DANA/dst) mengonfirmasi
 * pembayaran SUKSES, lalu menjalankan JALUR YANG SAMA PERSIS dengan
 * webhook asli (`confirmPaymentFromWebhook`) — supaya perilaku escrow/
 * wallet/notifikasi yang teruji tetap konsisten antara mock dan nanti
 * saat provider asli dipasang.
 */
export async function simulatePaymentSuccess(userId, paymentId, method) {
  const payment = await getPaymentForCheckout(userId, paymentId);
  if (payment.status !== "PENDING") {
    throw ApiError.conflict(`Pembayaran berstatus ${payment.status}, tidak bisa disimulasikan lagi`);
  }
  return confirmPaymentFromWebhook({
    providerReference: payment.provider_reference,
    status: "SUCCESS",
    rawPayload: { simulated: true, method: method ?? "UNKNOWN" },
  });
}
