import { query } from "../config/db.js";
import { ApiError } from "../utils/ApiError.js";

/**
 * Inti keamanan saldo: SATU fungsi ini adalah satu-satunya cara balance
 * wallet boleh berubah di seluruh codebase. Setiap pemanggil WAJIB
 * mengirim `client` dari withTransaction yang sedang berjalan (order
 * service, payment service, refund service, dst) — supaya perubahan
 * saldo dan perubahan status order selalu atomic bersama-sama.
 *
 * Urutan yang dijaga:
 *   1. Lock baris wallet (SELECT ... FOR UPDATE) supaya request paralel
 *      terhadap wallet yang sama antre, bukan balapan.
 *   2. Hitung balance_after di aplikasi (bukan `balance = balance + x`
 *      di SQL) supaya kita bisa validasi & catat balance_before/after.
 *   3. Insert baris ledger (wallet_transactions) — sumber kebenaran.
 *   4. Update kolom balance sebagai nilai cache dari ledger.
 *
 * idempotencyKey WAJIB unik per operasi bisnis (mis. `${orderId}:ESCROW_HOLD`)
 * supaya retry dari client/webhook tidak pernah mendobel efeknya.
 */
export async function applyWalletTransaction(client, {
  userId,
  type,
  amount, // positif = kredit (nambah saldo), negatif = debit (kurang saldo)
  referenceType,
  referenceId,
  idempotencyKey,
}) {
  // Cek idempotency lebih dulu: kalau key ini sudah pernah diproses,
  // kembalikan hasil yang sudah ada, jangan proses ulang.
  const existing = await client.query(
    "SELECT * FROM wallet_transactions WHERE idempotency_key = $1",
    [idempotencyKey]
  );
  if (existing.rows[0]) {
    return existing.rows[0];
  }

  const { rows: walletRows } = await client.query(
    "SELECT id, balance FROM wallets WHERE user_id = $1 FOR UPDATE",
    [userId]
  );
  const wallet = walletRows[0];
  if (!wallet) throw ApiError.internal("Wallet user tidak ditemukan");

  const balanceBefore = Number(wallet.balance);
  const balanceAfter = balanceBefore + amount;

  if (balanceAfter < 0) {
    throw ApiError.badRequest("Saldo tidak mencukupi");
  }

  const { rows } = await client.query(
    `INSERT INTO wallet_transactions
       (wallet_id, type, amount, balance_before, balance_after,
        reference_type, reference_id, idempotency_key)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     RETURNING *`,
    [wallet.id, type, amount, balanceBefore, balanceAfter, referenceType, referenceId, idempotencyKey]
  );

  await client.query("UPDATE wallets SET balance = $1 WHERE id = $2", [balanceAfter, wallet.id]);

  return rows[0];
}

export async function getWalletByUserId(userId) {
  const { rows } = await query("SELECT id, balance, currency FROM wallets WHERE user_id = $1", [
    userId,
  ]);
  if (!rows[0]) throw ApiError.notFound("Wallet tidak ditemukan");
  return rows[0];
}

export async function listWalletTransactions(userId, { page = 1, pageSize = 20 } = {}) {
  const wallet = await getWalletByUserId(userId);
  const offset = (page - 1) * pageSize;
  const { rows } = await query(
    `SELECT id, type, amount, balance_before, balance_after, reference_type, reference_id, created_at
     FROM wallet_transactions WHERE wallet_id = $1
     ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [wallet.id, pageSize, offset]
  );
  return rows;
}
