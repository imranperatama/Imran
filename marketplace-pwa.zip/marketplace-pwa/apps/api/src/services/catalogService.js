import { query } from "../config/db.js";
import { ApiError } from "../utils/ApiError.js";

export async function listGames() {
  const { rows } = await query(
    `SELECT id, name, slug, icon_url, banner_url
     FROM games WHERE is_active = true
     ORDER BY sort_order ASC, name ASC`
  );
  return rows;
}

export async function getGameBySlug(slug) {
  const { rows } = await query(
    `SELECT id, name, slug, icon_url, banner_url FROM games WHERE slug = $1 AND is_active = true`,
    [slug]
  );
  if (!rows[0]) throw ApiError.notFound("Game tidak ditemukan");
  return rows[0];
}

export async function listCategoriesByGame(gameId) {
  const { rows } = await query(
    `SELECT id, name, slug, sort_order FROM categories WHERE game_id = $1 ORDER BY sort_order ASC`,
    [gameId]
  );
  return rows;
}

/**
 * Listing produk publik. Selalu filter is_active = true dan JOIN stock
 * supaya buyer tidak melihat produk yang stoknya habis (untuk stock_type
 * LIMITED/SERIAL) sebagai "tersedia".
 */
export async function listProducts({ gameSlug, categoryId, q, page, pageSize }) {
  const conditions = ["p.is_active = true"];
  const params = [];

  if (gameSlug) {
    params.push(gameSlug);
    conditions.push(`g.slug = $${params.length}`);
  }
  if (categoryId) {
    params.push(categoryId);
    conditions.push(`p.category_id = $${params.length}`);
  }
  if (q) {
    params.push(`%${q}%`);
    conditions.push(`p.name ILIKE $${params.length}`);
  }

  const whereClause = conditions.join(" AND ");
  const offset = (page - 1) * pageSize;

  params.push(pageSize, offset);
  const { rows } = await query(
    `SELECT p.id, p.name, p.slug, p.price_amount, p.currency, p.thumbnail_url,
            p.product_type, g.name AS game_name, sp.store_name AS seller_name
     FROM products p
     JOIN games g ON g.id = p.game_id
     JOIN seller_profiles sp ON sp.id = p.seller_id
     WHERE ${whereClause}
     ORDER BY p.created_at DESC
     LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );

  const countResult = await query(
    `SELECT COUNT(*)::int AS total
     FROM products p JOIN games g ON g.id = p.game_id
     WHERE ${whereClause}`,
    params.slice(0, params.length - 2)
  );

  return { items: rows, total: countResult.rows[0].total, page, pageSize };
}

export async function getProductById(id) {
  const { rows } = await query(
    `SELECT p.id, p.name, p.slug, p.description, p.price_amount, p.currency,
            p.thumbnail_url, p.product_type, p.seller_id, p.is_active,
            g.name AS game_name, sp.store_name AS seller_name,
            COALESCE(ps.quantity_available, 0) AS stock_available,
            COALESCE(ps.stock_type, 'UNLIMITED') AS stock_type
     FROM products p
     JOIN games g ON g.id = p.game_id
     JOIN seller_profiles sp ON sp.id = p.seller_id
     LEFT JOIN product_stock ps ON ps.product_id = p.id
     WHERE p.id = $1`,
    [id]
  );
  if (!rows[0]) throw ApiError.notFound("Produk tidak ditemukan");
  return rows[0];
}
