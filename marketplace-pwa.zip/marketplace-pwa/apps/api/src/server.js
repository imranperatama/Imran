import { createApp } from "./app.js";
import { env } from "./config/env.js";
import { logger } from "./utils/logger.js";
import { pool } from "./config/db.js";

const app = createApp();

const server = app.listen(env.port, () => {
  logger.info(`API berjalan di port ${env.port} (${env.nodeEnv})`);
});

async function shutdown(signal) {
  logger.info(`Menerima ${signal}, mematikan server dengan aman...`);
  server.close(async () => {
    await pool.end();
    logger.info("Server berhenti.");
    process.exit(0);
  });
  // Paksa keluar kalau graceful shutdown macet > 10 detik
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
