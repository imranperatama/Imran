import { asyncHandler } from "../utils/asyncHandler.js";
import { listProductsQuerySchema } from "../validators/productValidators.js";
import {
  listGames,
  getGameBySlug,
  listCategoriesByGame,
  listProducts,
  getProductById,
} from "../services/catalogService.js";

export const getGames = asyncHandler(async (req, res) => {
  res.json({ data: await listGames() });
});

export const getGameDetail = asyncHandler(async (req, res) => {
  const game = await getGameBySlug(req.params.slug);
  const categories = await listCategoriesByGame(game.id);
  res.json({ data: { ...game, categories } });
});

export const getProducts = asyncHandler(async (req, res) => {
  const input = listProductsQuerySchema.parse(req.query);
  res.json({ data: await listProducts(input) });
});

export const getProductDetail = asyncHandler(async (req, res) => {
  res.json({ data: await getProductById(req.params.id) });
});
