import { asyncHandler } from "../utils/asyncHandler.js";
import { registerSchema, loginSchema } from "../validators/authValidators.js";
import { registerUser, authenticateUser, issueTokenPair, getUserById } from "../services/authService.js";
import { verifyRefreshToken } from "../utils/jwt.js";
import { ApiError } from "../utils/ApiError.js";
import { env } from "../config/env.js";

const REFRESH_COOKIE_NAME = "refresh_token";

function setRefreshCookie(res, token) {
  res.cookie(REFRESH_COOKIE_NAME, token, {
    httpOnly: true,
    secure: env.isProd,
    sameSite: "strict",
    path: "/api/auth",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

export const register = asyncHandler(async (req, res) => {
  const input = registerSchema.parse(req.body);
  const user = await registerUser(input);
  res.status(201).json({ data: user });
});

export const login = asyncHandler(async (req, res) => {
  const input = loginSchema.parse(req.body);
  const { accessToken, refreshToken, user } = await authenticateUser(input);
  setRefreshCookie(res, refreshToken);
  res.json({ data: { accessToken, user } });
});

export const refresh = asyncHandler(async (req, res) => {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];
  if (!token) throw ApiError.unauthorized("Refresh token tidak ditemukan");

  let payload;
  try {
    payload = verifyRefreshToken(token);
  } catch {
    throw ApiError.unauthorized("Refresh token tidak valid atau kedaluwarsa");
  }

  const user = await getUserById(payload.sub);
  if (!user || !user.is_active) throw ApiError.unauthorized("Akun tidak aktif");

  const { accessToken, refreshToken, user: publicUser } = issueTokenPair(user);
  setRefreshCookie(res, refreshToken);
  res.json({ data: { accessToken, user: publicUser } });
});

export const logout = asyncHandler(async (req, res) => {
  res.clearCookie(REFRESH_COOKIE_NAME, { path: "/api/auth" });
  res.status(204).send();
});

export const me = asyncHandler(async (req, res) => {
  const user = await getUserById(req.user.id);
  if (!user) throw ApiError.notFound("User tidak ditemukan");
  res.json({ data: user });
});
