import { asyncHandler } from "../utils/asyncHandler.js";
import { createProductSchema, updateProductSchema } from "../validators/productValidators.js";
import {
  createProduct,
  updateProduct,
  deleteProduct,
  listMyProducts,
} from "../services/sellerProductService.js";

export const postProduct = asyncHandler(async (req, res) => {
  const input = createProductSchema.parse(req.body);
  const product = await createProduct(req.user.id, input);
  res.status(201).json({ data: product });
});

export const patchProduct = asyncHandler(async (req, res) => {
  const input = updateProductSchema.parse(req.body);
  const product = await updateProduct(req.user.id, req.params.id, input);
  res.json({ data: product });
});

export const removeProduct = asyncHandler(async (req, res) => {
  await deleteProduct(req.user.id, req.params.id);
  res.status(204).send();
});

export const getMyProducts = asyncHandler(async (req, res) => {
  res.json({ data: await listMyProducts(req.user.id) });
});
