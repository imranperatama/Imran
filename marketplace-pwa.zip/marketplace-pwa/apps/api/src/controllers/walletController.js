import { asyncHandler } from "../utils/asyncHandler.js";
import { getWalletByUserId, listWalletTransactions } from "../services/walletService.js";

export const getMyWallet = asyncHandler(async (req, res) => {
  res.json({ data: await getWalletByUserId(req.user.id) });
});

export const getMyWalletTransactions = asyncHandler(async (req, res) => {
  const page = Number(req.query.page || 1);
  const pageSize = Number(req.query.pageSize || 20);
  res.json({ data: await listWalletTransactions(req.user.id, { page, pageSize }) });
});

// Dipakai di sellerRoutes.js — sengaja fungsi terpisah (bukan reuse nama)
// supaya jelas ini dipanggil di bawah guard requireRole("seller").
export const getSellerWallet = getMyWallet;
export const getSellerWalletTransactions = getMyWalletTransactions;
