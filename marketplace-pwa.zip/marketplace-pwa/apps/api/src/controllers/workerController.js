import { z } from "zod";
import { asyncHandler } from "../utils/asyncHandler.js";
import { claimNextJob } from "../services/botJobService.js";
import { applyBotJobResult } from "../services/orderService.js";

const resultSchema = z.object({
  status: z.enum(["SUCCESS", "FAILED"]),
  result: z.record(z.any()).optional(),
});

// Worker memanggil ini saat idle untuk minta job berikutnya.
export const getNextJob = asyncHandler(async (req, res) => {
  const workerId = req.header("X-Worker-Id") || "unknown-worker";
  const job = await claimNextJob(workerId);
  res.json({ data: job }); // null kalau tidak ada job -> worker tidur & polling lagi
});

// Worker melaporkan hasil eksekusi job (sukses/gagal).
export const postJobResult = asyncHandler(async (req, res) => {
  const input = resultSchema.parse(req.body);
  const idempotencyKey = req.header("Idempotency-Key") || `${req.params.id}:${input.status}`;
  const job = await applyBotJobResult(req.params.id, input, idempotencyKey);
  res.json({ data: job });
});
