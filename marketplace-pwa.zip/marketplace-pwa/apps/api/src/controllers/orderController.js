import { asyncHandler } from "../utils/asyncHandler.js";
import { createOrderSchema } from "../validators/orderValidators.js";
import {
  createOrder,
  getOrderDetail,
  listOrdersByBuyer,
  listOrdersBySeller,
} from "../services/orderService.js";
import { ApiError } from "../utils/ApiError.js";
import { query } from "../config/db.js";

export const postOrder = asyncHandler(async (req, res) => {
  const input = createOrderSchema.parse(req.body);
  const order = await createOrder(req.user.id, input, req.idempotencyKey);
  res.status(201).json({ data: order });
});

export const getMyOrders = asyncHandler(async (req, res) => {
  res.json({ data: await listOrdersByBuyer(req.user.id) });
});

export const getMySellerOrders = asyncHandler(async (req, res) => {
  res.json({ data: await listOrdersBySeller(req.user.id) });
});

export const getOrder = asyncHandler(async (req, res) => {
  const order = await getOrderDetail(req.params.id);

  // Otorisasi: hanya buyer pemilik order, seller yang terlibat, atau admin.
  const isOwner = order.buyer_id === req.user.id;
  const isAdmin = req.user.role === "admin";
  if (!isOwner && !isAdmin) {
    const { rows } = await query(
      `SELECT 1 FROM order_items oi JOIN seller_profiles sp ON sp.id = oi.seller_id
       WHERE oi.order_id = $1 AND sp.user_id = $2 LIMIT 1`,
      [order.id, req.user.id]
    );
    if (rows.length === 0) throw ApiError.forbidden("Bukan order milikmu");
  }

  res.json({ data: order });
});
