import { asyncHandler } from "../utils/asyncHandler.js";
import { listNotifications, markNotificationRead } from "../services/notificationService.js";
import { sseHub } from "../realtime/sseHub.js";

export const getNotifications = asyncHandler(async (req, res) => {
  const page = Number(req.query.page || 1);
  const pageSize = Number(req.query.pageSize || 20);
  res.json({ data: await listNotifications(req.user.id, { page, pageSize }) });
});

export const patchNotificationRead = asyncHandler(async (req, res) => {
  await markNotificationRead(req.user.id, req.params.id);
  res.status(204).send();
});

/**
 * Endpoint SSE: `GET /api/notifications/stream`. Frontend membuka ini
 * dengan `new EventSource(url)` dan menerima event 'notification' setiap
 * kali ada notifikasi baru — dipakai untuk badge/toast realtime tanpa
 * polling berulang.
 */
export const streamNotifications = asyncHandler(async (req, res) => {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no", // matikan buffering kalau di belakang Nginx
  });
  res.write(`event: connected\ndata: {}\n\n`);

  sseHub.addConnection(req.user.id, res);

  // Heartbeat supaya koneksi tidak ditutup proxy/load balancer karena idle.
  const heartbeat = setInterval(() => res.write(": ping\n\n"), 25_000);

  req.on("close", () => {
    clearInterval(heartbeat);
    sseHub.removeConnection(req.user.id, res);
  });
});
