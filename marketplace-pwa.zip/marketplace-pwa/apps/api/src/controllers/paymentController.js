import { asyncHandler } from "../utils/asyncHandler.js";
import {
  initiatePayment,
  confirmPaymentFromWebhook,
  getPaymentForCheckout,
  simulatePaymentSuccess,
} from "../services/paymentService.js";
import { verifyWebhookSignature } from "../providers/mockPaymentProvider.js";
import { ApiError } from "../utils/ApiError.js";
import { z } from "zod";

const initiateSchema = z.object({ orderId: z.string().uuid() });
const simulateSchema = z.object({ method: z.enum(["GOPAY", "OVO", "DANA", "SHOPEEPAY"]).optional() });

export const postInitiatePayment = asyncHandler(async (req, res) => {
  const { orderId } = initiateSchema.parse(req.body);
  const payment = await initiatePayment(orderId, req.idempotencyKey);
  res.status(201).json({ data: payment });
});

// Dipanggil halaman "bayar" (Pay.jsx) untuk menampilkan nominal — nominal
// SELALU dari sini (server), bukan dari input manual di frontend.
export const getPayment = asyncHandler(async (req, res) => {
  const payment = await getPaymentForCheckout(req.user.id, req.params.id);
  res.json({ data: payment });
});

// DEV/SANDBOX ONLY — lihat komentar di paymentService.simulatePaymentSuccess
// dan middleware/devOnly.js. Tidak aktif kalau NODE_ENV=production.
export const postSimulatePayment = asyncHandler(async (req, res) => {
  const { method } = simulateSchema.parse(req.body);
  const payment = await simulatePaymentSuccess(req.user.id, req.params.id, method);
  res.json({ data: payment });
});

/**
 * Endpoint webhook — TIDAK boleh dipasangi requireAuth (provider eksternal
 * tidak punya JWT kita). Keamanannya bertumpu 100% pada verifikasi
 * signature di bawah ini, bukan pada siapa yang memanggil.
 *
 * req.body di sini adalah Buffer mentah (lihat app.js: express.raw()
 * khusus dipasang untuk route ini, terpisah dari express.json() global).
 */
export const postPaymentWebhook = asyncHandler(async (req, res) => {
  const signature = req.header("X-Signature");
  const rawBody = req.body; // Buffer

  if (!verifyWebhookSignature(rawBody, signature)) {
    throw ApiError.unauthorized("Signature webhook tidak valid");
  }

  let payload;
  try {
    payload = JSON.parse(rawBody.toString("utf8"));
  } catch {
    throw ApiError.badRequest("Payload webhook bukan JSON valid");
  }

  const { providerReference, status } = payload;
  if (!providerReference || !["SUCCESS", "FAILED"].includes(status)) {
    throw ApiError.badRequest("Payload webhook tidak lengkap");
  }

  const payment = await confirmPaymentFromWebhook({ providerReference, status, rawPayload: payload });
  res.json({ data: { received: true, paymentId: payment.id } });
});
