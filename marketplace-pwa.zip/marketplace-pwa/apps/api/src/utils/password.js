import argon2 from "argon2";

/**
 * Argon2id — pemenang Password Hashing Competition, direkomendasikan
 * OWASP di atas bcrypt untuk aplikasi baru. Parameter di bawah adalah
 * baseline OWASP 2024 (silakan naikkan memoryCost jika server kuat).
 */
const OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19456, // 19 MiB
  timeCost: 2,
  parallelism: 1,
};

export async function hashPassword(plain) {
  return argon2.hash(plain, OPTIONS);
}

export async function verifyPassword(hash, plain) {
  try {
    return await argon2.verify(hash, plain);
  } catch {
    return false;
  }
}
