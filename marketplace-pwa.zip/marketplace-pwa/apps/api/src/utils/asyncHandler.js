/**
 * Bungkus controller async supaya error-nya otomatis lempar ke
 * Express error handler (`next(err)`) tanpa perlu try/catch berulang
 * di setiap controller.
 */
export function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
