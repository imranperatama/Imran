import jwt from "jsonwebtoken";
import { env } from "../config/env.js";

/**
 * Access token: umur pendek (default 15m), dipakai untuk otorisasi tiap
 * request. Refresh token: umur panjang (default 7d), dipakai HANYA untuk
 * menerbitkan access token baru lewat /api/auth/refresh, disimpan sebagai
 * HTTP-only cookie supaya tidak bisa dibaca JavaScript di browser (mitigasi XSS).
 */
export function signAccessToken(payload) {
  return jwt.sign(payload, env.jwt.accessSecret, { expiresIn: env.jwt.accessTtl });
}

export function signRefreshToken(payload) {
  return jwt.sign(payload, env.jwt.refreshSecret, { expiresIn: env.jwt.refreshTtl });
}

export function verifyAccessToken(token) {
  return jwt.verify(token, env.jwt.accessSecret);
}

export function verifyRefreshToken(token) {
  return jwt.verify(token, env.jwt.refreshSecret);
}
