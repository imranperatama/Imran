import pg from "pg";
import { env } from "./env.js";
import { logger } from "../utils/logger.js";

const { Pool } = pg;

/**
 * Satu pool koneksi ke Supabase Postgres untuk seluruh aplikasi.
 * Gunakan `withTransaction` untuk operasi yang menyentuh saldo/status
 * transaksi — supaya selalu dibungkus BEGIN/COMMIT/ROLLBACK dengan benar.
 */
export const pool = new Pool({
  connectionString: env.databaseUrl,
  ssl: env.isProd ? { rejectUnauthorized: false } : undefined,
  max: 10,
  idleTimeoutMillis: 30_000,
});

pool.on("error", (err) => {
  logger.error({ err }, "Unexpected error pada idle client Postgres");
});

/**
 * Jalankan query biasa (read-only atau single-statement write yang tidak
 * butuh konsistensi multi-statement).
 */
export async function query(text, params) {
  return pool.query(text, params);
}

/**
 * Jalankan sekumpulan operasi dalam satu database transaction.
 * `fn` menerima `client` dan HARUS memakai client itu untuk semua query
 * di dalamnya (bukan `pool.query`), supaya tetap dalam transaction yang sama.
 *
 * Dipakai untuk semua operasi yang mengubah saldo wallet atau status order,
 * sesuai catatan keamanan di database/schema.sql.
 */
export async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
