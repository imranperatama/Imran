import "dotenv/config";

/**
 * Semua env yang dibutuhkan backend dikumpulkan & divalidasi di sini,
 * supaya proses gagal cepat (fail fast) saat start kalau ada yang hilang,
 * bukan gagal di tengah-tengah request produksi.
 */
const required = [
  "DATABASE_URL",
  "JWT_ACCESS_SECRET",
  "JWT_REFRESH_SECRET",
  "PAYMENT_WEBHOOK_SECRET",
  "WORKER_API_KEY",
];

const missing = required.filter((key) => !process.env[key]);
if (missing.length > 0) {
  // eslint-disable-next-line no-console
  console.error(`[FATAL] Environment variable hilang: ${missing.join(", ")}`);
  process.exit(1);
}

export const env = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: Number(process.env.PORT || 4000),
  databaseUrl: process.env.DATABASE_URL,
  corsOrigin: process.env.CORS_ORIGIN || "http://localhost:5173",
  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET,
    refreshSecret: process.env.JWT_REFRESH_SECRET,
    accessTtl: process.env.JWT_ACCESS_TTL || "15m",
    refreshTtl: process.env.JWT_REFRESH_TTL || "7d",
  },
  paymentWebhookSecret: process.env.PAYMENT_WEBHOOK_SECRET,
  workerApiKey: process.env.WORKER_API_KEY,
  isProd: (process.env.NODE_ENV || "development") === "production",
};
