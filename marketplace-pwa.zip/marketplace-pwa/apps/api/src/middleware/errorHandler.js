import { logger } from "../utils/logger.js";

/**
 * Error handler terpusat. Kunci keamanan di sini: kalau errornya BUKAN
 * ApiError (artinya bug/unexpected), jangan pernah bocorkan pesan/stack
 * asli ke client — cukup log di server dan balas pesan generik.
 */
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err.isApiError) {
    if (err.statusCode >= 500) {
      logger.error({ err, path: req.path }, err.message);
    } else {
      logger.warn({ path: req.path, statusCode: err.statusCode }, err.message);
    }
    return res.status(err.statusCode).json({
      error: { message: err.message, details: err.details ?? undefined },
    });
  }

  logger.error({ err, path: req.path }, "Unhandled error");
  return res.status(500).json({ error: { message: "Terjadi kesalahan pada server" } });
}
