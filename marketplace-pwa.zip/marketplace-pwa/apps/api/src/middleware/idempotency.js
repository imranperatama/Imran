import { ApiError } from "../utils/ApiError.js";

/**
 * Wajibkan header Idempotency-Key untuk endpoint yang mengubah state
 * finansial (create order, konfirmasi bayar, refund, dst). Key-nya
 * sendiri divalidasi keunikannya di level database (kolom UNIQUE),
 * middleware ini cuma memastikan header-nya ada dan formatnya masuk akal.
 */
export function requireIdempotencyKey(req, res, next) {
  const key = req.header("Idempotency-Key");
  if (!key || key.length < 8 || key.length > 100) {
    return next(
      ApiError.badRequest(
        "Header Idempotency-Key wajib diisi (8-100 karakter) untuk operasi ini"
      )
    );
  }
  req.idempotencyKey = key;
  next();
}
