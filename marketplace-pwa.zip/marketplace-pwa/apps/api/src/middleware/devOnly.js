import { env } from "../config/env.js";
import { ApiError } from "../utils/ApiError.js";

/**
 * Blokir endpoint ini di production. Dipakai khusus untuk endpoint
 * simulasi pembayaran (bukan payment gateway asli) — supaya tidak
 * mungkin "kepencet" aktif di production dan bikin orang kira
 * transaksi selesai padahal uangnya tidak pernah benar-benar diproses.
 */
export function devOnly(req, res, next) {
  if (env.isProd) {
    return next(ApiError.notFound());
  }
  next();
}
