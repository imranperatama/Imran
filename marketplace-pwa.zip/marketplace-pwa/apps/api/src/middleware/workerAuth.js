import crypto from "node:crypto";
import { env } from "../config/env.js";
import { ApiError } from "../utils/ApiError.js";

/**
 * Worker Python bukan "user" — jadi tidak pakai JWT login biasa.
 * Ia diautentikasi dengan API key statis (WORKER_API_KEY) yang hanya
 * diketahui backend & worker, dikirim di header X-Worker-Key.
 *
 * Dibandingkan pakai timingSafeEqual supaya tidak bocor lewat timing attack.
 */
export function requireWorkerAuth(req, res, next) {
  const key = req.header("X-Worker-Key") || "";
  const expected = env.workerApiKey;

  const a = Buffer.from(key);
  const b = Buffer.from(expected);
  const valid = a.length === b.length && crypto.timingSafeEqual(a, b);

  if (!valid) {
    return next(ApiError.unauthorized("Worker API key tidak valid"));
  }
  next();
}
