import { verifyAccessToken } from "../utils/jwt.js";
import { ApiError } from "../utils/ApiError.js";

/**
 * requireAuth: memverifikasi access token dari header Authorization
 * (Bearer <token>). Menaruh payload token (id user + role) di req.user.
 *
 * PENTING: req.user hanya berisi apa yang ADA DI TOKEN saat login.
 * Untuk keputusan yang butuh data terbaru (mis. is_active terkini),
 * service layer tetap query ulang ke database, bukan percaya token 100%.
 */
export function requireAuth(req, res, next) {
  const header = req.header("Authorization") || "";
  const [scheme, token] = header.split(" ");

  if (scheme !== "Bearer" || !token) {
    return next(ApiError.unauthorized("Token akses tidak ditemukan"));
  }

  try {
    const payload = verifyAccessToken(token);
    req.user = { id: payload.sub, role: payload.role };
    next();
  } catch {
    next(ApiError.unauthorized("Token akses tidak valid atau kedaluwarsa"));
  }
}

/**
 * requireRole: RBAC di level server — ini yang benar-benar menegakkan
 * aturan buyer/seller/admin, BUKAN sekadar menyembunyikan tombol di UI.
 * Selalu dipasang SETELAH requireAuth.
 */
export function requireRole(...allowedRoles) {
  return function roleGuard(req, res, next) {
    if (!req.user) {
      return next(ApiError.unauthorized());
    }
    if (!allowedRoles.includes(req.user.role)) {
      return next(ApiError.forbidden(`Aksi ini hanya untuk role: ${allowedRoles.join(", ")}`));
    }
    next();
  };
}

/**
 * requireAuthSSE: varian requireAuth khusus endpoint SSE. Browser API
 * `EventSource` tidak bisa mengirim custom header Authorization, jadi
 * untuk endpoint stream ini saja token dikirim lewat query string
 * (`?token=...`). Token yang dipakai tetap access token yang sama
 * (umur pendek), bukan token baru dengan privilege berbeda.
 */
export function requireAuthSSE(req, res, next) {
  const token = req.query.token;
  if (!token) return next(ApiError.unauthorized("Token akses tidak ditemukan"));
  try {
    const payload = verifyAccessToken(token);
    req.user = { id: payload.sub, role: payload.role };
    next();
  } catch {
    next(ApiError.unauthorized("Token akses tidak valid atau kedaluwarsa"));
  }
}
/**
 * optionalAuth: tempel req.user kalau ada token valid, tapi tidak
 * menolak request kalau tidak ada. Berguna untuk endpoint publik yang
 * perilakunya sedikit berbeda kalau user login (mis. wishlist status).
 */
export function optionalAuth(req, res, next) {
  const header = req.header("Authorization") || "";
  const [scheme, token] = header.split(" ");
  if (scheme === "Bearer" && token) {
    try {
      const payload = verifyAccessToken(token);
      req.user = { id: payload.sub, role: payload.role };
    } catch {
      // token invalid diabaikan, tetap dianggap anonymous
    }
  }
  next();
}
