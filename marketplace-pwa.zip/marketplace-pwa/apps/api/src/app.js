import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import pinoHttp from "pino-http";
import cookieParser from "cookie-parser";

import { env } from "./config/env.js";
import { logger } from "./utils/logger.js";
import routes from "./routes/index.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { notFound } from "./middleware/notFound.js";
import { postPaymentWebhook } from "./controllers/paymentController.js";

export function createApp() {
  const app = express();

  // Di belakang reverse proxy (Railway/Render/Nginx) supaya req.ip &
  // rate limiter membaca IP asli client, bukan IP proxy.
  app.set("trust proxy", 1);

  app.use(helmet());
  app.use(
    cors({
      origin: env.corsOrigin,
      credentials: true, // wajib untuk cookie refresh token
    })
  );
  // Webhook payment WAJIB dipasang SEBELUM express.json() global, dan
  // pakai express.raw() supaya body mentah tersedia untuk verifikasi
  // HMAC signature (lihat paymentController.postPaymentWebhook).
  app.post(
    "/api/payments/webhook",
    express.raw({ type: "application/json", limit: "1mb" }),
    postPaymentWebhook
  );

  app.use(express.json({ limit: "1mb" }));
  app.use(cookieParser());
  app.use(pinoHttp({ logger }));

  // Rate limit umum untuk seluruh API. Endpoint sensitif (login/register)
  // punya limiter lebih ketat lagi di authRoutes.js.
  app.use(
    rateLimit({
      windowMs: 1 * 60 * 1000,
      limit: 120,
      standardHeaders: true,
      legacyHeaders: false,
    })
  );

  app.use("/api", routes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}
