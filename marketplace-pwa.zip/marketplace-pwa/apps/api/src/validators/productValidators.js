import { z } from "zod";

export const createProductSchema = z.object({
  gameId: z.string().uuid(),
  categoryId: z.string().uuid(),
  name: z.string().min(3).max(200),
  description: z.string().max(5000).optional(),
  productType: z.enum(["MANUAL", "AUTOMATED"]).default("MANUAL"),
  priceAmount: z.number().int().nonnegative(), // integer rupiah, BUKAN float
  thumbnailUrl: z.string().url().optional(),
  initialStock: z.number().int().nonnegative().default(0),
});

export const updateProductSchema = createProductSchema.partial();

export const listProductsQuerySchema = z.object({
  gameSlug: z.string().optional(),
  categoryId: z.string().uuid().optional(),
  q: z.string().max(200).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(20),
});
