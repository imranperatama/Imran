import { z } from "zod";

// Frontend HANYA mengirim productId + quantity. Harga, ketersediaan
// stok, dan siapa penjualnya SEMUA ditentukan backend dari database
// saat order dibuat — sesuai aturan keamanan di ARCHITECTURE.md.
export const createOrderSchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string().uuid(),
        quantity: z.number().int().min(1).max(99),
      })
    )
    .min(1)
    .max(20),
});
