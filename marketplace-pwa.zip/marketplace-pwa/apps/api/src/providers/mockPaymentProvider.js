import crypto from "node:crypto";
import { env } from "../config/env.js";

/**
 * Provider MOCK untuk development — TIDAK memproses uang sungguhan.
 * Saat siap pakai payment gateway asli (Midtrans/Xendit/dll), ganti
 * SELURUH isi file ini dengan SDK resmi mereka; kontrak fungsinya
 * (createPaymentIntent, verifyWebhookSignature) dipertahankan supaya
 * paymentService.js di atasnya tidak perlu berubah.
 *
 * CATATAN: `redirectUrl` di bawah TIDAK dipakai lagi oleh frontend saat
 * ini — frontend sekarang redirect ke halaman "bayar" internal sendiri
 * (`/pay/:paymentId`, lihat apps/web/src/pages/Pay.jsx) yang mensimulasikan
 * pemilihan e-wallet. Field ini dipertahankan di response supaya kontrak
 * data tetap mirip provider asli (yang memang mengembalikan redirect URL
 * ke halaman checkout mereka) — kalau nanti ganti ke provider asli,
 * frontend tinggal diarahkan ke `redirectUrl` itu alih-alih `/pay/:id`.
 */

// Simulasi endpoint provider: sebenarnya provider asli akan redirect user
// ke halaman pembayaran mereka. Di mock ini kita cuma generate reference.
export function createPaymentIntent({ orderId, amount }) {
  const providerReference = `MOCK-${orderId.slice(0, 8)}-${Date.now()}`;
  return {
    providerReference,
    // URL dummy — di dunia nyata ini URL checkout dari provider.
    redirectUrl: `https://mock-payment.local/pay/${providerReference}?amount=${amount}`,
  };
}

/**
 * Verifikasi signature webhook. Provider asli biasanya kirim header
 * X-Signature = HMAC-SHA256(rawBody, webhookSecret). Kita mock persis
 * pola itu supaya swap ke provider asli nanti minim perubahan.
 *
 * PENTING: rawBody harus body MENTAH (belum di-JSON.parse), karena HMAC
 * dihitung dari byte persis yang dikirim provider.
 */
export function verifyWebhookSignature(rawBody, signatureHeader) {
  if (!signatureHeader) return false;
  const expected = crypto
    .createHmac("sha256", env.paymentWebhookSecret)
    .update(rawBody)
    .digest("hex");

  // timingSafeEqual mencegah timing attack saat membandingkan signature.
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(signatureHeader, "utf8");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
