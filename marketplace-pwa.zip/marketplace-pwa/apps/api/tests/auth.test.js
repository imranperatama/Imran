import test from "node:test";
import assert from "node:assert/strict";
import { hashPassword, verifyPassword } from "../src/utils/password.js";
import { signAccessToken, verifyAccessToken, signRefreshToken, verifyRefreshToken } from "../src/utils/jwt.js";

test("password hash tidak pernah menyimpan plaintext dan verify bekerja", async () => {
  const hash = await hashPassword("SuperSecret123");
  assert.notEqual(hash, "SuperSecret123");
  assert.ok(await verifyPassword(hash, "SuperSecret123"));
  assert.ok(!(await verifyPassword(hash, "password-salah")));
});

test("access token & refresh token round-trip dengan benar", () => {
  const access = signAccessToken({ sub: "user-1", role: "buyer" });
  const payload = verifyAccessToken(access);
  assert.equal(payload.sub, "user-1");
  assert.equal(payload.role, "buyer");

  const refresh = signRefreshToken({ sub: "user-1", role: "buyer", jti: "abc" });
  const refreshPayload = verifyRefreshToken(refresh);
  assert.equal(refreshPayload.jti, "abc");
});

test("access token tidak valid diverifikasi dengan refresh secret (harus gagal)", () => {
  const access = signAccessToken({ sub: "user-1", role: "buyer" });
  assert.throws(() => verifyRefreshToken(access));
});
