import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";

// Set env sebelum import module yang membacanya di top-level.
process.env.PAYMENT_WEBHOOK_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || "test-webhook-secret";
process.env.DATABASE_URL = process.env.DATABASE_URL || "postgres://test";
process.env.JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || "test";
process.env.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "test";
process.env.WORKER_API_KEY = process.env.WORKER_API_KEY || "test";

const { verifyWebhookSignature } = await import("../src/providers/mockPaymentProvider.js");

test("verifyWebhookSignature menolak signature yang salah", () => {
  const body = Buffer.from(JSON.stringify({ providerReference: "MOCK-1", status: "SUCCESS" }));
  assert.equal(verifyWebhookSignature(body, "signature-ngasal"), false);
});

test("verifyWebhookSignature menerima signature HMAC yang benar", () => {
  const body = Buffer.from(JSON.stringify({ providerReference: "MOCK-1", status: "SUCCESS" }));
  const validSignature = crypto
    .createHmac("sha256", process.env.PAYMENT_WEBHOOK_SECRET)
    .update(body)
    .digest("hex");
  assert.equal(verifyWebhookSignature(body, validSignature), true);
});

test("verifyWebhookSignature menolak kalau header tidak ada", () => {
  const body = Buffer.from("{}");
  assert.equal(verifyWebhookSignature(body, undefined), false);
});
