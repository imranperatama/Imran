import test from "node:test";
import assert from "node:assert/strict";
import { withTransaction } from "../src/config/db.js";
import { applyWalletTransaction } from "../src/services/walletService.js";

/**
 * Test ini butuh koneksi DATABASE_URL nyata (Supabase) untuk jalan —
 * jalankan dengan: node --test tests/wallet.test.js
 * Setup: pastikan ada user + wallet dummy di DB dulu (lihat catatan di README testing).
 */

test("applyWalletTransaction menolak saldo jadi negatif", async () => {
  await withTransaction(async (client) => {
    // Ambil salah satu wallet yang ada untuk uji coba (harus sudah ada dari register user).
    const { rows } = await client.query("SELECT user_id, balance FROM wallets LIMIT 1");
    if (rows.length === 0) {
      console.log("SKIP: tidak ada wallet di database untuk diuji");
      return;
    }
    const { user_id: userId, balance } = rows[0];

    await assert.rejects(
      () =>
        applyWalletTransaction(client, {
          userId,
          type: "WITHDRAWAL",
          amount: -(Number(balance) + 1_000_000), // sengaja lebih besar dari saldo
          referenceType: "test",
          referenceId: null,
          idempotencyKey: `test-negative-${Date.now()}`,
        }),
      /Saldo tidak mencukupi/
    );

    // Rollback otomatis karena test ini sengaja tidak commit (withTransaction luar
    // akan commit, jadi di real run sebaiknya bungkus test dengan transaction
    // terpisah yang di-rollback paksa — lihat catatan di README testing).
  });
});

test("applyWalletTransaction idempotent untuk key yang sama", async () => {
  await withTransaction(async (client) => {
    const { rows } = await client.query("SELECT user_id FROM wallets LIMIT 1");
    if (rows.length === 0) {
      console.log("SKIP: tidak ada wallet di database untuk diuji");
      return;
    }
    const userId = rows[0].user_id;
    const key = `test-idempotent-${Date.now()}`;

    const first = await applyWalletTransaction(client, {
      userId,
      type: "ADJUSTMENT",
      amount: 1,
      referenceType: "test",
      referenceId: null,
      idempotencyKey: key,
    });
    const second = await applyWalletTransaction(client, {
      userId,
      type: "ADJUSTMENT",
      amount: 1,
      referenceType: "test",
      referenceId: null,
      idempotencyKey: key,
    });

    assert.equal(first.id, second.id, "Request kedua dengan key sama harus mengembalikan baris yang sama");
  });
});
