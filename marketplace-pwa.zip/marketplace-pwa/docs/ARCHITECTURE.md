# Blueprint Arsitektur — Marketplace PWA

**Tahap 1 dari 10** — Blueprint arsitektur & database schema.

---

## 1. Ringkasan Sistem

Marketplace digital (mirip itemku) dengan tiga komponen utama yang saling terpisah dan berkomunikasi lewat API/webhook, bukan lewat akses database bersama secara langsung dari sisi client:

```
┌─────────────────┐      REST/JWT       ┌──────────────────┐
│   PWA (React)    │ ─────────────────▶ │  Backend (Node)   │
│  apps/web        │ ◀───── SSE/WS ───── │  apps/api         │
└─────────────────┘                     └──────────┬────────┘
                                                     │ SQL (pg)
                                                     ▼
                                          ┌──────────────────┐
                                          │ Supabase Postgres │
                                          └──────────┬────────┘
                                                     │ job dibuat
                                                     ▼
                                          ┌──────────────────┐
                                          │ Worker (Python)   │
                                          │  apps/worker      │
                                          └──────────┬────────┘
                                                     │ webhook hasil job
                                                     ▼
                                          kembali ke Backend (Node)
```

Prinsip inti: **frontend tidak pernah dipercaya**. Semua keputusan bisnis (harga, status pembayaran, status escrow, kapan dana dilepas) ditentukan backend berdasarkan data di database, bukan dari payload yang dikirim client.

## 2. Tanggung Jawab Tiap Komponen

**`apps/web` (PWA)**
- UI buyer & seller, autentikasi, katalog, checkout, wallet, notifikasi realtime.
- Tidak menyimpan logika harga/status — hanya menampilkan apa yang backend kembalikan.

**`apps/api` (Backend)**
- Satu-satunya pihak yang boleh menulis ke database transaksional (orders, payments, escrow, wallet).
- Orchestrator: membuat `bot_jobs` setelah pembayaran terkonfirmasi, memvalidasi hasil dari worker, memperbarui status order & saldo.
- Sumber kebenaran untuk RBAC, idempotency, dan verifikasi webhook.

**`apps/worker` (Python)**
- Hanya mengeksekusi *job* yang sudah diberi backend (mis. topup otomatis).
- Tidak pernah mengubah saldo langsung — hanya melaporkan hasil (`SUCCESS`/`FAILED`) lewat webhook yang diverifikasi.

**Database (Supabase Postgres)**
- Sumber kebenaran tunggal. Semua perubahan status & saldo dibungkus transaction DB + tercatat di ledger (`wallet_transactions`) dan `audit_logs`.

## 3. Alur Status Order (State Machine)

```
CREATED → PAYMENT_PENDING → PAYMENT_CONFIRMED → ESCROW_HELD → PROCESSING → DELIVERED → COMPLETED
                                    │
                                    └──▶ REFUND → REFUNDED
```

Untuk produk otomatis (`product_type = AUTOMATED`): begitu `ESCROW_HELD`, backend membuat baris di `bot_jobs`. Worker mengambil job → proses → lapor via `POST /api/worker/jobs/:id/result` → backend memvalidasi lalu memindahkan order ke `DELIVERED`/`COMPLETED`, atau `RETRY`/`MANUAL_REVIEW`/`REFUND` jika gagal.

## 4. Keamanan yang Dipegang Sejak Desain Awal

- **Tidak ada logika harga di frontend** — backend mengambil `price_amount` dari tabel `products` saat membuat order.
- **Idempotency key** wajib di `orders`, `payments`, dan `wallet_transactions` — mencegah duplikasi akibat retry/double-click.
- **Webhook payment** diverifikasi via signature provider, bukan dipercaya begitu saja dari payload.
- **Saldo wallet** tidak pernah di-update langsung (`balance += x`) — selalu lewat insert ke `wallet_transactions` dengan `balance_before`/`balance_after`, dalam satu DB transaction dengan row lock (`SELECT ... FOR UPDATE`) pada baris wallet.
- **RBAC**: kolom `role` di `users` (`buyer`/`seller`/`admin`) diperiksa di middleware backend, bukan cuma disembunyikan di UI.
- **Audit trail**: setiap perubahan status penting (order, escrow, wallet, refund) dicatat di `audit_logs`.

## 5. Struktur Monorepo (Tahap 1)

```
marketplace-pwa/
├── apps/
│   ├── web/        ← dibuat di Tahap 8
│   ├── api/         ← dibuat mulai Tahap 2
│   └── worker/      ← dibuat di Tahap 7
├── packages/
│   ├── shared/
│   ├── database/    ← schema.sql ada di sini
│   └── types/
├── database/
│   └── schema.sql    ← lihat file terpisah
├── .env.example
└── README.md
```

## 6. Yang Sudah Selesai vs Yang Akan Datang

| Tahap | Isi | Status |
|---|---|---|
| 1 | Blueprint arsitektur + database schema | ✅ Selesai (dokumen ini) |
| 2 | Backend Node.js + Express (skeleton clean) | Berikutnya |
| 3 | Authentication + RBAC | Menunggu |
| 4 | Product/catalog system | Menunggu |
| 5 | Order + escrow + wallet ledger | Menunggu |
| 6 | Payment webhook (verifikasi + idempotency) | Menunggu |
| 7 | Python worker + job queue | Menunggu |
| 8 | Frontend PWA (React + Vite) | Menunggu |
| 9 | Realtime notification | Menunggu |
| 10 | Testing, security review, deployment, PWA optimization | Menunggu |

Katakan "lanjut tahap 2" kapan pun kamu siap.
