# Security Checklist — Marketplace PWA

Status implementasi per item spesifikasi awal (`🔐 Security Requirements`).

| Item | Status | Lokasi |
|---|---|---|
| Password hashing Argon2id | ✅ | `apps/api/src/utils/password.js` |
| JWT access (15m) + refresh (7d) | ✅ | `apps/api/src/utils/jwt.js` |
| Refresh token di HTTP-only cookie | ✅ | `apps/api/src/controllers/authController.js` (`sameSite: strict`, `secure` di prod) |
| RBAC buyer/seller/admin (server-side) | ✅ | `apps/api/src/middleware/auth.js` (`requireRole`) |
| Input validation (Zod) | ✅ | `apps/api/src/validators/*.js` — semua body/query divalidasi sebelum masuk service |
| Rate limiting | ✅ | `app.js` (global 120/menit) + `authRoutes.js` (login/register 20/15menit) |
| CORS restrictive | ✅ | `app.js` — origin dari `CORS_ORIGIN`, `credentials: true` |
| Helmet | ✅ | `app.js` |
| SQL injection protection | ✅ | Semua query pakai parameterized query (`$1, $2, ...`), tidak ada string concat SQL |
| XSS protection | ⚠️ Parsial | Access token disimpan di memori (bukan localStorage) untuk kurangi dampak XSS; tetap **wajib** escape/sanitize input HTML apapun kalau nanti ada rich text (belum ada di scope ini) |
| CSRF protection | ✅ | `sameSite: strict` pada cookie refresh + endpoint mutasi butuh Bearer token (bukan cookie) — cookie-based CSRF klasik tidak applicable karena API tidak pakai cookie untuk otorisasi |
| Server-side authorization | ✅ | Tiap controller cek kepemilikan resource (lihat `orderController.getOrder`, `sellerProductService.assertOwnership`) |
| Idempotency untuk transaksi | ✅ | `middleware/idempotency.js` + kolom UNIQUE `idempotency_key` di `orders`, `payments`, `wallet_transactions` |
| Audit log | ✅ | `audit_logs` table, ditulis di titik-titik kritis (`orderService.writeAudit`) |
| Transaction/locking untuk saldo | ✅ | `walletService.applyWalletTransaction` — `SELECT ... FOR UPDATE` + satu ledger sumber kebenaran |
| Tidak simpan password plaintext | ✅ | Hanya `password_hash` yang disimpan |
| Tidak simpan secret di frontend | ✅ | `apps/web` tidak punya `.env` berisi secret — hanya `VITE_API_BASE_URL` |
| Tidak percaya harga dari frontend | ✅ | `orderService.createOrder` mengambil ulang `price_amount` dari DB, mengabaikan angka apapun dari client |

## Yang Perlu Dilakukan Manual Sebelum Production

1. **Ganti semua secret di `.env`** (`JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, `PAYMENT_WEBHOOK_SECRET`, `WORKER_API_KEY`) — jangan pernah pakai nilai contoh dari `.env.example`.
2. **RLS Supabase**: sudah diaktifkan di semua tabel (tanpa policy) — ini SENGAJA memblokir akses langsung lewat `anon`/`authenticated` key. Backend memakai `SUPABASE_SERVICE_ROLE_KEY`/`DATABASE_URL` langsung yang **bypass RLS**. Jangan pernah expose `service_role` key ke frontend.
3. **Ganti mock payment provider** (`apps/api/src/providers/mockPaymentProvider.js`) dengan SDK resmi provider asli sebelum menerima uang sungguhan.
4. **Isi kredensial & selector Playwright asli** di `apps/worker/bot/topup_bot.py` — saat ini masih stub yang sengaja `raise` error.
5. **Pertimbangkan 2FA/verifikasi email** untuk akun seller (belum ada di scope 10 tahap ini).
6. **Set `NODE_ENV=production`** di deployment supaya cookie `secure: true` aktif dan log level tidak terlalu verbose.
7. **Review rate limit** sesuai traffic asli — angka di `app.js`/`authRoutes.js` adalah baseline, bukan angka final.
8. **Backup & retention policy** untuk `audit_logs` dan `wallet_transactions` — jangan pernah hapus baris ledger, itu adalah catatan keuangan.

## Known Limitations (baca sebelum menganggap "selesai")

- SSE hub (`realtime/sseHub.js`) in-memory — tidak akan bekerja benar kalau backend di-scale ke >1 instance tanpa Redis pub/sub. Lihat komentar di file tersebut.
- Belum ada refund flow otomatis (tabel `refunds` sudah ada, tapi endpoint `/api/refunds` dari spesifikasi awal belum diimplementasi — perlu keputusan bisnis: refund otomatis vs approval admin manual).
- Belum ada halaman admin (moderasi seller, manual review `bot_jobs` berstatus `MANUAL_REVIEW`, dll).
- Test coverage baru contoh (wallet ledger, auth, webhook signature) — bukan coverage penuh semua endpoint.
