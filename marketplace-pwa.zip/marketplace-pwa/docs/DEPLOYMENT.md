# Deployment — Marketplace PWA

## Ringkasan Infrastruktur

| Komponen | Rekomendasi | Alasan |
|---|---|---|
| Database | Supabase Postgres (sudah aktif) | Sudah dipakai sejak Tahap 1, managed, ada connection pooler |
| Backend (`apps/api`) | Railway / Render / Fly.io | Perlu long-running process untuk SSE — **hindari platform serverless murni** (Vercel Functions dll) karena koneksi SSE butuh koneksi persisten |
| Frontend (`apps/web`) | Vercel / Netlify / Cloudflare Pages | Static build hasil `vite build`, cocok untuk platform static hosting + CDN |
| Worker (`apps/worker`) | VM kecil / container terpisah (Railway worker service, Fly.io machine) | Proses jangka panjang (polling loop) + butuh Playwright/Chromium terinstall |

## Langkah Deploy Backend

1. Set semua env dari `apps/api/.env.example` di dashboard platform (isi nilai asli, bukan contoh).
2. Set `NODE_ENV=production`.
3. Build step: `npm install` (tidak ada build step lain, backend pakai ESM native Node).
4. Start command: `npm start` (menjalankan `src/server.js`).
5. Health check endpoint: `GET /api/health`.
6. Pastikan platform mempertahankan koneksi HTTP lama untuk SSE (`/api/notifications/stream`) — set timeout proxy cukup panjang (mis. 60s+) atau nonaktifkan idle timeout untuk path itu.

## Deploy Frontend ke Netlify (khusus, karena monorepo)

Proyek ini monorepo (`apps/web`, `apps/api`, `apps/worker` dalam satu repo),
jadi Netlify butuh tahu folder mana yang di-build. Sudah disediakan
`netlify.toml` di root repo — kalau connect lewat Netlify UI manual,
isi persis begini (JANGAN gabung "apps/web" ke publish directory lagi,
karena base sudah "apps/web" — kalau digabung jadi dobel path):

- **Base directory**: `apps/web`
- **Build command**: `npm run build`
- **Publish directory**: `dist`

Env var yang WAJIB diset di dashboard Netlify (Site settings → Environment variables):
- `VITE_API_BASE_URL` = URL backend production kamu, contoh `https://api-domain-kamu.com/api`

`apps/web/public/_redirects` (isi: `/*  /index.html  200`) sudah ditambahkan
supaya React Router bisa handle deep link seperti `/games` atau `/orders/:id`
tanpa Netlify balas 404 — tanpa file ini, buka URL itu langsung (bukan lewat
klik dari halaman lain) akan 404 karena Netlify mencari file fisik di path itu.

## Langkah Deploy Frontend (Umum)

1. Set `VITE_API_BASE_URL` (atau update proxy) ke URL backend production.
2. Build: `npm run build` → hasil di `dist/`.
3. Deploy folder `dist/` ke static hosting.
4. Pastikan HTTPS aktif (wajib untuk PWA installable & Service Worker).
5. Cek `manifest.webmanifest` ter-generate dengan benar dan icon 192/512 sudah diisi (lihat `public/icons/README.txt`).

## Langkah Deploy Worker

1. Container dengan Python 3.12 + `pip install -r requirements.txt` + `playwright install --with-deps chromium`.
2. Set env dari `apps/worker/.env.example`.
3. Start command: `python main.py`.
4. Jalankan sebagai **long-running process** (bukan cron/serverless) karena ini polling loop.
5. Untuk scale >1 worker instance: aman, karena job locking pakai `SELECT ... FOR UPDATE SKIP LOCKED` di `botJobService.js` — beberapa worker boleh polling bersamaan tanpa rebutan job yang sama.

## PWA Optimization Checklist

- [ ] Isi icon 192x192 & 512x512 di `apps/web/public/icons/`
- [ ] Test "Add to Home Screen" di Android Chrome & desktop Chrome
- [ ] Lighthouse PWA audit skor ≥ 90 sebelum rilis
- [ ] Pastikan `navigateFallbackDenylist` di `vite.config.js` tetap mengecualikan `/api` (data transaksi tidak boleh di-cache Service Worker)
- [ ] Test offline shell (buka app tanpa koneksi — harus tetap render UI, walau data kosong/error state)

## Reverse Proxy / Load Balancer Notes

Kalau pakai Nginx di depan backend:
```nginx
location /api/notifications/stream {
    proxy_pass http://backend;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering off;       # penting untuk SSE
    proxy_read_timeout 3600s;  # jangan putus koneksi SSE terlalu cepat
}
```
